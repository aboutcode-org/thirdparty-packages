==============================================================================
examples
==============================================================================

.. _`execnet-dev`: http://mail.python.org/mailman/listinfo/execnet-dev
.. _`execnet-commit`: http://mail.python.org/mailman/listinfo/execnet-commit

Note: all examples with `>>>` prompts are automatically tested.

.. toctree::
   :maxdepth: 2

   example/test_info
   example/test_group
   example/test_proxy
   example/test_multi
   example/hybridpython
   example/test_debug

.. toctree::
   :hidden:

   example/test_ssh_fileserver
