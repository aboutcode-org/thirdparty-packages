from .magic import PyinstrumentMagic
