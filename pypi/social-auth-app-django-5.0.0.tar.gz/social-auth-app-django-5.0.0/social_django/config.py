# For backward compatibility. You should use the configuration from apps module
from .apps import PythonSocialAuthConfig  # noqa: F401
