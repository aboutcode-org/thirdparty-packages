from __future__ import unicode_literals
from .service import Service  # noqa:flake8

__version__ = '1.1.0-rc2'
