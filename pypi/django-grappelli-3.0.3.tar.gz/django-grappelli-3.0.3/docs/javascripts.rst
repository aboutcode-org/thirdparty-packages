.. |grappelli| replace:: Grappelli
.. |filebrowser| replace:: FileBrowser

.. _javascripts:

Javascripts
===========

Grappelli overwrites some javascripts (see `static/admin/js/`). All modifications are marked with `GRAPPELLI CUSTOM`.
