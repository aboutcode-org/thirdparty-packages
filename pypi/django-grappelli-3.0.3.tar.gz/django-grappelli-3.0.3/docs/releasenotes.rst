:tocdepth: 1

.. |grappelli| replace:: Grappelli
.. |filebrowser| replace:: FileBrowser

.. _releasenotes:

Grappelli 3.0.x Release Notes
=============================

**Grappelli 3.0.x is compatible with Django 4.0**.

Update from Grappelli 2.15.x
----------------------------

* Update Django to 4.0 and check https://docs.djangoproject.com/en/4.0/releases/4.0/
* Update Grappelli to 3.0.x
