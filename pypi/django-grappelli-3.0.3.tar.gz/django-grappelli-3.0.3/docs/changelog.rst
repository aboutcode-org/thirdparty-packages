:tocdepth: 1

.. |grappelli| replace:: Grappelli
.. |filebrowser| replace:: FileBrowser

.. _changelog:

Changelog
=========

3.0.4 (not yet released)
------------------------

3.0.3 (February 18th 2022)
--------------------------

* Fixed utf-8 characters in TinyMCE staticfiles.

3.0.2 (January 21st 2022)
-------------------------

* Fixed changelist actions.

3.0.1 (January 12th 2022)
-------------------------

* First release of Grappelli which is compatible with Django 4.0.
