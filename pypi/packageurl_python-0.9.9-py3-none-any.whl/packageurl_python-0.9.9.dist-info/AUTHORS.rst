The following organizations or individuals have contributed to
packageurl-python:

- Philippe Ombredanne @pombredanne
- Jiri Popelka @jpopelka
- Thomas Druez @tdruez
- Jono Yang @JonoYang
- Sebastian Schuberth @sschuberth
- Tushar Goel @TG1999
- Haiko Schol @haikoschol