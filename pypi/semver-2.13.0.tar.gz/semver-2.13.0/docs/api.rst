.. _api:

API
===

.. automodule:: semver
   :members:
   :undoc-members:
