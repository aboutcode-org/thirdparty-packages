Semver |version| -- Semantic Versioning
=======================================


.. toctree::
   :maxdepth: 2
   :caption: Contents

   readme
   install
   usage
   pysemver
   development
   api
   changelog


Indices and Tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
