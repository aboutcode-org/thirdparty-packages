.. # ------------------( SYNOPSIS                           )------------------

========================
Project Functional Tests
========================

This subpackage provides *all* pytest_-based **functional tests** (i.e.,
callables exercising the functional behaviour of this project *without* regard
to this project's public API) for this project.

.. # ------------------( LINKS                              )------------------
.. _pytest:
   https://docs.pytest.org
