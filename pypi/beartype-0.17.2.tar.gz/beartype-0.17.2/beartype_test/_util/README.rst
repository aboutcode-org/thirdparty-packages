.. # ------------------( SYNOPSIS                           )------------------

======================
Project Test Utilities
======================

This subpackage provides pytest_-based **utilities** (i.e., general-purpose
lower-level pytest_ fixtures and related functions leveraged by higher-level
unit and functional tests) for this project's test suite.

.. # ------------------( LINKS                              )------------------
.. _pytest:
   https://docs.pytest.org
