#!/usr/bin/env python3
# --------------------( LICENSE                            )--------------------
# Copyright (c) 2014-2024 Beartype authors.
# See "LICENSE" for further details.

'''
Semantically empty submodule containing only only zero or more whitespace
characters zero or more inline comments, and this prefacing module docstring --
exercising a pernicious edge case in AST transformation that actually happened
and destroyed everything.
'''
