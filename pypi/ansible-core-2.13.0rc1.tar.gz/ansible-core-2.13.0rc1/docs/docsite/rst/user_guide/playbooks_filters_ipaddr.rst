:orphan:

.. _playbooks_filters_ipaddr:

ipaddr filter
`````````````

This document has moved to :ref:`plugins_in_ansible.utils`.
