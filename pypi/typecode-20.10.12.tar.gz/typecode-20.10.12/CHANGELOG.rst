Release notes
-------------
### Version 20.10.

*2020-10-05* -- Code for content-based lexers from Pygments has been updated from v 2.2.0 to v 2.7.1
             -- Create data driven filetype tests and update test expectations

### Version 20.09.

*2020-09-24* -- Initial release.
