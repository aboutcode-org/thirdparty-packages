Release notes
=============

vNext
-----

Version 21.1.21
---------------

*2020-01-21*
- Improve error reporting when oding missing DLLs
- Clean config and improve basic documentation


Version 21.1.14
---------------

*2020-11-12*
- Update dependencies

*2020-11-12*
- Add Azure Pipelines CI support

*2021-01-14*
- Drop Python 2 support
- Update license


Version 20.10.08
----------------

*2020-10-08*
- Add support for both python 2 + 3

*2020-10-08*
- Add CI support for python 2 + 3

Version 20.10
-------------

* Minimal fixes needed for proper release


Version 20.09.30
----------------

*2020-09-25*
- Update to PEP 517/518 development practices
- Add some minimal documentation

Version 20.09
-------------

*2020-09-24*
- Initial release.
