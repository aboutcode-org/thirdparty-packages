import unittest

if __name__ == "__main__":
    unittest.main(module="dowsing.tests", verbosity=2)
