A ScanCode Toolkit plugin to use pre-installed libarchive library
=================================================================

the path of libarchive.so is either determined by distro data or explicitily
taken from ``EXTRACTCODE_LIBARCHIVE_PATH`` environment variable
