VERSION = '2.14.2'
default_app_config = 'grappelli.apps.GrappelliConfig'
