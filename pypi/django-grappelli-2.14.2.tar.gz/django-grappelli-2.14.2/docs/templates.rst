:tocdepth: 1

.. |grappelli| replace:: Grappelli
.. |filebrowser| replace:: FileBrowser

.. _templates:

Templates
=========

|grappelli| includes a Documentation about the HTML/CSS framework. If you're using the default URL-pattern (see :ref:`quickstart`) you'll find the documentation at ``/grappelli/grp-doc/`` (by default, these URLs are commented out).