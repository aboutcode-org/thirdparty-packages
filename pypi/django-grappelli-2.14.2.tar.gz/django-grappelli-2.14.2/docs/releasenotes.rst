:tocdepth: 1

.. |grappelli| replace:: Grappelli
.. |filebrowser| replace:: FileBrowser

.. _releasenotes:

Grappelli 2.14.x Release Notes
==============================

**Grappelli 2.14.x is compatible with Django 3.0**.

Update from Grappelli 2.13.x
----------------------------

* Update Django to 3.0 and check https://docs.djangoproject.com/en/3.0/releases/3.0/
* Update Grappelli to 2.14.x
