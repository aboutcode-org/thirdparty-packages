Contributing
============

See <http://inveniosoftware.org/wiki/Development/Contributing> for now.
