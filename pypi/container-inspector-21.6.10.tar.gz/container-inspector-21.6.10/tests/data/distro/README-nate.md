# os_release collection 

Originally from https://gist.github.com/natefoo/814c5bf936922dad97ff
for https://github.com/natefoo/lionshead MIT-licensed
