# -*- coding: utf-8 -*-
from __future__ import unicode_literals, absolute_import
"""Top-level package for Dependency Parser."""

__author__ = """Jannis Gebauer"""
__email__ = 'jay@pyup.io'
__version__ = '0.5.0'

from .parser import parse
