# -*- coding: utf-8 -*-
from __future__ import unicode_literals, absolute_import

requirements_txt = "requirements.txt"
conda_yml = "conda.yml"
setup_cfg = "setup.cfg"
tox_ini = "tox.ini"
pipfile = "Pipfile"
pipfile_lock = "Pipfile.lock"
