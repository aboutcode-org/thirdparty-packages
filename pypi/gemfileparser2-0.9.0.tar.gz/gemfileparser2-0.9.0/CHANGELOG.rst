Changelog
=========


v0.9.0
-------

Rename to gemfileparser2.