# sample installed package w/ .egg-info file.
__package__ = 'funny'
