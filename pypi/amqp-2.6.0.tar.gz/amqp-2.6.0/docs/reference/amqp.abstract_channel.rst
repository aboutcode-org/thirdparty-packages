=====================================================
 ``amqp.abstract_channel``
=====================================================

.. contents::
    :local:
.. currentmodule:: amqp.abstract_channel

.. automodule:: amqp.abstract_channel
    :members:
    :undoc-members:
