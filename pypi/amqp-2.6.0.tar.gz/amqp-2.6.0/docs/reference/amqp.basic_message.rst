=====================================================
 ``amqp.basic_message``
=====================================================

.. contents::
    :local:
.. currentmodule:: amqp.basic_message

.. automodule:: amqp.basic_message
    :members:
    :undoc-members:
