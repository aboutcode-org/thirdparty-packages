=====================================================
 ``amqp.platform``
=====================================================

.. contents::
    :local:
.. currentmodule:: amqp.platform

.. automodule:: amqp.platform
    :members:
    :undoc-members:
