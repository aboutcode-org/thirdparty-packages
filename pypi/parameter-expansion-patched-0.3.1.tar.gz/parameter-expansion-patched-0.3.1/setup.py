#!/usr/bin/env python

import setuptools

setuptools.setup()
