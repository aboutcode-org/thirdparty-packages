Status
------

**This project is unmaintained**. It was originally spun off of
django-auth-ldap, which no longer requires it. If you have a use for it, feel
free to copy the code for your own purposes (it's only for testing, after all).

Documentation may still be available at https://mockldap.readthedocs.io/.
