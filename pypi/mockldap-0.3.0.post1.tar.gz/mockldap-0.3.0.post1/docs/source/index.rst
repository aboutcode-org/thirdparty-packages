mockldap
========

.. include:: ../../README.rst

.. toctree::
    :maxdepth: 2

    overview
    directories
    operations
    changes


License
-------

.. include:: ../../LICENSE.rst
