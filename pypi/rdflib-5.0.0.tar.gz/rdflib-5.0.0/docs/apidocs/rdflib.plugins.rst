rdflib.plugins package
======================

Subpackages
-----------

.. toctree::

   rdflib.plugins.parsers
   rdflib.plugins.serializers
   rdflib.plugins.sparql
   rdflib.plugins.stores

Submodules
----------

rdflib.plugins.memory module
----------------------------

.. automodule:: rdflib.plugins.memory
   :members:
   :undoc-members:
   :show-inheritance:

rdflib.plugins.sleepycat module
-------------------------------

.. automodule:: rdflib.plugins.sleepycat
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: rdflib.plugins
   :members:
   :undoc-members:
   :show-inheritance:
