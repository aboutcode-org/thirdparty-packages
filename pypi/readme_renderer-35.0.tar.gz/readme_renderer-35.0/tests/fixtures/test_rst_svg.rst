.. image:: https://example.com/badge.svg
