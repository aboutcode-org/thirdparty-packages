This is normal text.

```python
def this_is_python():
    """This is a docstring."""
    pass
<script type="text/javascript">alert('I am evil.');</script>
```
