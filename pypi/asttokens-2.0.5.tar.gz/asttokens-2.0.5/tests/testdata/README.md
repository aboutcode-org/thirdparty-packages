Everything in astroid subdirectories comes from the astroid library's test suite, which cover a
variety of Python syntax constructs.
