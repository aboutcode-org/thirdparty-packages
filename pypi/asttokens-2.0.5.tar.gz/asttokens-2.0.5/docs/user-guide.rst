User Guide
==========

.. include:: ../README.rst
  :start-after: Start of user-guide
