urlpatterns = []  # type: ignore
