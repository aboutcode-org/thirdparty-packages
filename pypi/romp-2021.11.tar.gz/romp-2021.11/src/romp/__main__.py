import romp.cli

romp.cli.main()
