===================
License and Credits
===================

``django-environ`` is open source software licensed under the
`MIT / X11 License <https://choosealicense.com/licenses/mit/>`_.
The full license text can be also found in the `source code repository <https://github.com/joke2k/django-environ/blob/main/LICENSE.txt>`_.

.. include:: ../AUTHORS.rst
