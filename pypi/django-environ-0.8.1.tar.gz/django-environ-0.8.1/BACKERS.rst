Backers and supporters
======================

You can join them in supporting django-environ development by visiting our page
on `Open Collective <https://opencollective.com/django-environ>`_ and becoming
a sponsor or a backer!

Sponsors
--------

Support this project by becoming a sponsor. Your logo will show up here with a
link to your website. `Became sponsor <https://opencollective.com/django-environ/contribute/sponsors-3474/checkout>`_.

|ocsponsor0| |ocsponsor1|

Backers
-------

Thank you to all our backers!

|ocbackerimage|

.. |ocsponsor0| image:: https://opencollective.com/django-environ/sponsor/0/avatar.svg
    :target: https://triplebyte.com/
    :alt: Sponsor
.. |ocsponsor1| image:: https://images.opencollective.com/static/images/become_sponsor.svg
    :target: https://opencollective.com/django-environ/contribute/sponsors-3474/checkout
    :alt: Become a Sponsor
.. |ocbackerimage| image:: https://opencollective.com/django-environ/backers.svg?width=890
    :target: https://opencollective.com/django-environ
    :alt: Backers on Open Collective
