Security Policy
===============


Reporting a Vulnerability
-------------------------

If you discover a security vulnerability within ``django-environ``, please
send an e-mail to Serghei Iakovlev via egrep@protonmail.ch. All security
vulnerabilities will be promptly addressed.
