collect_ignore = [
    # this module fails mypy tests because 'setup.py' matches './setup.py'
    'prepare/example/setup.py',
]
