Added shortcut for accepting auto suggestion
============================================

Added End key shortcut for accepting auto-suggestion
This binding works in Vi mode too, provided 
TerminalInteractiveShell.emacs_bindings_in_vi_insert_mode is set to be True.

