Issues closed in the 8.x development cycle
==========================================

GitHub stats for 2022/01/05 - 2022/01/12 (tag: 8.0.0rc1)

These lists are automatically generated, and may be incomplete or contain duplicates.

We closed 26 issues and merged 307 pull requests.
The full list can be seen `on GitHub <https://github.com/ipython/ipython/issues?q=milestone%3A8.0>`__

The following 99 authors contributed 372 commits.

* 007vedant
* Adam Hackbarth
* Aditya Sathe
* Ahmed Fasih
* Albert Zhang
* Alex Hall
* Andrew Port
* Ankitsingh6299
* Arthur Moreira
* Ashwin Vishnu
* Augusto
* BaoGiang HoangVu
* bar-hen
* Bart Skowron
* Bartosz Telenczuk
* Bastian Ebeling
* Benjamin Ragan-Kelley
* Blazej Michalik
* blois
* Boyuan Liu
* Brendan Gerrity
* Carol Willing
* Coco Bennett
* Coco Mishra
* Corentin Cadiou
* Daniel Goldfarb
* Daniel Mietchen
* Daniel Shimon
* digitalvirtuoso
* Dimitri Papadopoulos
* dswij
* Eric Wieser
* Erik
* Ethan Madden
* Faris A Chugthai
* farisachugthai
* Gal B
* gorogoroumaru
* Hussaina Begum Nandyala
* Inception95
* Iwan Briquemont
* Jake VanderPlas
* Jakub Klus
* James Morris
* Jay Qi
* Jeroen Bédorf
* Joyce Er
* juacrumar
* Juan Luis Cano Rodríguez
* Julien Rabinow
* Justin Palmer
* Krzysztof Cybulski
* L0uisJ0shua
* lbennett
* LeafyLi
* Lightyagami1
* Lumir Balhar
* Mark Schmitz
* Martin Skarzynski
* martinRenou
* Matt Wozniski
* Matthias Bussonnier
* Meysam Azad
* Michael T
* Michael Tiemann
* Naelson Douglas
* Nathan Goldbaum
* Nick Muoh
* nicolaslazo
* Nikita Kniazev
* NotWearingPants
* Paul Ivanov
* Paulo S. Costa
* Pete Blois
* Peter Corke
* PhanatosZou
* Piers Titus van der Torren
* Rakessh Roshan
* Ram Rachum
* rchiodo
* Reilly Tucker Siemens
* Romulo Filho
* rushabh-v
* Sammy Al Hashemi
* Samreen Zarroug
* Samuel Gaist
* Sanjana-03
* Scott Sanderson
* skalaydzhiyski
* sleeping
* Snir Broshi
* Spas Kalaydzhisyki
* Sylvain Corlay
* Terry Davis
* Timur Kushukov
* Tobias Bengfort
* Tomasz Kłoczko
* Yonatan Goldschmidt
* 谭九鼎
