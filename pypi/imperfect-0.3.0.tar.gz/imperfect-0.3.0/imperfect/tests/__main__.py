import unittest

from .editing import EditingTest  # noqa: F401
from .imperfect import ImperfectTests  # noqa: F401

unittest.main()
