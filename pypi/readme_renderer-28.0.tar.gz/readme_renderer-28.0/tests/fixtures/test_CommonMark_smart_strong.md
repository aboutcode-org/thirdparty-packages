Regular __double underscore__ words.

Text with double__underscore__words.
