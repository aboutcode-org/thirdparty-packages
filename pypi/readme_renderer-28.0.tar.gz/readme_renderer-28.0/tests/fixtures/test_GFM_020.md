foo@bar.baz
