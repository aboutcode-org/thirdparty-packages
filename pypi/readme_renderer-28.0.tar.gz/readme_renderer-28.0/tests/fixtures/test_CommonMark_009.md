Normal text

<details>
 <summary>Why am I getting an error during installation/when launching rtv?</summary>
</details>
