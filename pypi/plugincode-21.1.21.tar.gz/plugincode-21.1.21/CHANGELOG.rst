Release notes
=============

Version 21.1.21
---------------

*2021-01-21*
- Set proper minimum version of dependencies


Version 21.1.15
---------------

*2021-01-15*
- Drop Python 2 support and require latest version of commoncode


Version 20.09
-------------

*2020-09-24*
- Initial release.
