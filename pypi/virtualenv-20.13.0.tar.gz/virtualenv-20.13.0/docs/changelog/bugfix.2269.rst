Fix ``AttributeError: 'bool' object has no attribute 'error'`` when creating a
Python 2.x virtualenv on macOS - by ``moreati``
