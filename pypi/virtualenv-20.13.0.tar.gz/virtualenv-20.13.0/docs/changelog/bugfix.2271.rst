Fix ``PermissionError: [Errno 1] Operation not permitted`` when creating a
Python 2.x virtualenv on macOS/arm64 - by ``moreati``
