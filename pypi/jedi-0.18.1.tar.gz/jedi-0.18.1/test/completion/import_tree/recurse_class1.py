from . import recurse_class2

class C(recurse_class2.C):
    def a(self):
        pass
