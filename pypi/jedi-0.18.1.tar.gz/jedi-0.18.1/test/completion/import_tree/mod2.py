from . import mod1 as fake
