from PyQt4.QtCore import *
from PyQt4.QtGui import *

#? ['QActionGroup']
QActionGroup

#? ['currentText']
QStyleOptionComboBox().currentText

#? []
QStyleOptionComboBox().currentText.

from PyQt4 import QtGui

#? ['currentText']
QtGui.QStyleOptionComboBox().currentText

#? []
QtGui.QStyleOptionComboBox().currentText.
