Languages
=========

.. module:: babel.languages

The languages module provides functionality to access data about
languages that is not bound to a given locale.

Official Languages
------------------

.. autofunction:: get_official_languages

.. autofunction:: get_territory_language_info
