.. JSONStreams documentation master file, created by
   sphinx-quickstart on Mon Aug 22 17:12:38 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

JSONStreams
===========

Description
-----------

.. include:: description.rst


Contents:

.. toctree::
   :maxdepth: 2

   examples
   api
   changes


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

