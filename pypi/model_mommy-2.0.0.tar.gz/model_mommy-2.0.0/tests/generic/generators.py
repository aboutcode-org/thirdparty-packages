def gen_value_string():
    return 'value'
