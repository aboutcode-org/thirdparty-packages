__version__ = '2.0.0'
__title__ = 'model_mommy'
__author__ = 'Vanderson Mota'
__license__ = 'Apache 2.0'

import warnings
warnings.warn('Important: model_mommy is no longer maintained. Please use model_bakery instead: https://pypi.org/project/model-bakery/', DeprecationWarning)

from .utils import seq  # NoQA
