def do_stuff():
    a = 1
    return a
