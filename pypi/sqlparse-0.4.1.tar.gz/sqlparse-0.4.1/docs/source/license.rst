License
=======

.. include:: ../../LICENSE