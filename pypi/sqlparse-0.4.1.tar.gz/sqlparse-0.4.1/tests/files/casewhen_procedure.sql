create procedure procName()
begin
  select case when column = 'value' then column else 0 end;
end;
create procedure procName()
begin
  select 1;
end;
