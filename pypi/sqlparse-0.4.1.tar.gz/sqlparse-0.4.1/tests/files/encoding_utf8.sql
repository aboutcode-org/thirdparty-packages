select *
from foo
where bar = '齐天大圣.カラフルな雲.사랑해요'