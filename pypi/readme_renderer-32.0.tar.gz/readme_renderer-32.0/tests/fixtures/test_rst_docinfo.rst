:Project:   pg_query -- Pythonic wrapper around libpg_query
:Created:   mer 02 ago 2017 14:49:24 CEST
:Author:    Lele Gaifax <lele@metapensiero.it>
:License:   GNU General Public License version 3 or later
:Copyright: © 2017, 2018 Lele Gaifax

==========
 pg_query
==========
