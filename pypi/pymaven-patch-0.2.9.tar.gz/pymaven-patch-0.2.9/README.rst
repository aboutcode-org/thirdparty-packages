=======
Pymaven
=======

Overview
========

Pymaven is a Python library for interfacing with the maven build system. There
are two major interfaces:

* pymaven.client provides a basic maven repository client
* pymaven.pom provides a Pom object that can provide progromatic access to
  a maven pom file
