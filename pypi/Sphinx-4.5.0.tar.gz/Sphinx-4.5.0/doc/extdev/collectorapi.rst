.. _collector-api:

Environment Collector API
-------------------------

.. module:: sphinx.environment.collectors

.. autoclass:: EnvironmentCollector
   :members:
