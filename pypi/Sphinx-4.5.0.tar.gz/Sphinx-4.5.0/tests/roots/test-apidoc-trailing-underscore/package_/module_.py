""" A module with a trailing underscore """


class SomeClass_:
    """ A class with a trailing underscore """


def some_function_(some_arg_):
    """ A function with a trailing underscore in name and argument """
