.. _foo_1:

foo/foo_1
=========
