from sphinx.writers.html import HTMLTranslator


class ExtHTMLTranslator(HTMLTranslator):
    pass
