========
``util``
========

.. automodule:: invoke.util
    :exclude-members: ExceptionWrapper

.. autoclass:: invoke.util.ExceptionWrapper
    :no-members:
