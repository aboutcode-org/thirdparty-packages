from .registry import *

__title__ = 'regipy'
__version__ = '1.9.4'
