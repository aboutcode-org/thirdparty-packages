Changelog
=========


v30.0.0
-------

Initial release based on pip at commit 5cf98408f48a0ef91d61aea56485a7a83f6bbfa8
e.g., https://github.com/pypa/pip/tree/5cf98408f48a0ef91d61aea56485a7a83f6bbfa8
