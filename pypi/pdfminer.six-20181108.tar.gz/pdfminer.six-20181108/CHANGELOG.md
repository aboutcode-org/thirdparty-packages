# List of changes

## Version 20181108
 - PR #141 to speedup layout analysis
 - PR #173 for using argparse and replace deprecated getopt
 - PR #142 to compile pdfminer.six with cython, successfully