from .registry import *
__title__ = 'regipy'
__version__ = '3.0.2'
