A ScanCode Toolkit plugin to provide pre-built binary libraries and utilities
and their locations. This is for the RPM command which is built from sources
with the support for many rpmdb formats.
