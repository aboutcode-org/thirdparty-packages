=========================
Resolving JSON References
=========================


.. currentmodule:: jsonschema

.. autoclass:: RefResolver
    :members:

.. autoexception:: RefResolutionError

    A JSON reference failed to resolve.
