A ScanCode Toolkit plugin to use pre-installed libmagic library and data file.

The path to libmagic and its database is determined from well known distro
locations.
