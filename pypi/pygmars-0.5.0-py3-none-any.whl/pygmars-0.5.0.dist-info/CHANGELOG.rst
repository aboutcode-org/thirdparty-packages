================
Changelog
================

Version 0.0.1
---------------

* Initial version derived from NLTK HEAD at a5690ee
