.. include:: ./_build/README.pprst

Contents
========

.. toctree::
    :maxdepth: 2

    api

.. toctree::
    :maxdepth: 1

    license
    testing
    versions
