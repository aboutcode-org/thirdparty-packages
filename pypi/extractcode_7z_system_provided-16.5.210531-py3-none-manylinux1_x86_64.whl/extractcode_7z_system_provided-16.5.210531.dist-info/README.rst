A ScanCode Toolkit plugin to use pre-installed 7zip executables
===============================================================

the path of 7zip is either determined by distro data or explicitily
taken from ``EXTRACTCODE_7Z_PATH`` environment variable
