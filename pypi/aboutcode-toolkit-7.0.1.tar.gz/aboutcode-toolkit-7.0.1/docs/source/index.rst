=================================
AboutCode Toolkit's Documentation
=================================

Welcome to the AboutCode Toolkit's Documentation.

.. toctree::
   :maxdepth: 2

   AboutCode Toolkit <home.rst>
   General <general.rst>
   Specification <specification.rst>
   Reference <reference.rst>
   Type of Errors <type_of_errors.rst>
