==========================================================
 Semaphores - ``kombu.asynchronous.semaphore``
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.asynchronous.semaphore

.. automodule:: kombu.asynchronous.semaphore
    :members:
    :undoc-members:
