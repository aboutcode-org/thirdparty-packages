========================================================================
 Azure Storage Queues Transport - ``kombu.transport.azurestoragequeues``
========================================================================

.. currentmodule:: kombu.transport.azurestoragequeues

.. automodule:: kombu.transport.azurestoragequeues

    .. contents::
        :local:

    Transport
    ---------

    .. autoclass:: Transport
        :members:
        :undoc-members:

    Channel
    -------

    .. autoclass:: Channel
        :members:
        :undoc-members:
