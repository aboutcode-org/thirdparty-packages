========================
boolean.py documentation
========================

.. toctree::
   :maxdepth: 2

   users_guide
   concepts
   development_guide
   acknowledgements

