===============
Acknowledgments
===============

#. Nicolaie Popescu-Bodorin: Review of "*Concepts and Definitions*"
#. Silviu Ionut Carp: Review of "*Concepts and Definitions*"
