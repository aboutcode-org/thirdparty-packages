====================================
 ``celery.utils.collections``
====================================

.. currentmodule:: celery.utils.collections

.. contents::
    :local:

.. automodule:: celery.utils.collections
    :members:
    :undoc-members:
