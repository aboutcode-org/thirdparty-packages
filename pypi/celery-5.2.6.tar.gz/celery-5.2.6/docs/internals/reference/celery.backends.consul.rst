==========================================
 celery.backends.consul
==========================================

.. contents::
    :local:
.. currentmodule:: celery.backends.consul

.. automodule:: celery.backends.consul
    :members:
    :undoc-members:
