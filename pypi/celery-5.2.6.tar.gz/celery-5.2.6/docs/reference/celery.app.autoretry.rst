===================================
 ``celery.app.autoretry``
===================================

.. contents::
    :local:
.. currentmodule:: celery.app.autoretry

.. automodule:: celery.app.autoretry
    :members:
    :undoc-members:
