==================================================
 ``celery.worker.consumer.connection``
==================================================

.. contents::
    :local:
.. currentmodule:: celery.worker.consumer.connection

.. automodule:: celery.worker.consumer.connection
    :members:
    :undoc-members:
