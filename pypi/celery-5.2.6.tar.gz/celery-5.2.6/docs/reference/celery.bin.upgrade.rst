=====================================================
 ``celery.bin.upgrade``
=====================================================

.. contents::
    :local:
.. currentmodule:: celery.bin.upgrade

.. automodule:: celery.bin.upgrade
    :members:
    :undoc-members:
