## v0.1.1

* Bugfix, adds missing `packaging` requirement.

## v0.1.0

* Initial release

