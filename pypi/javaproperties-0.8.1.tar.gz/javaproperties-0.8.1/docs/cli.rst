Command-Line Utilities
======================
As of version 0.4.0, the command-line programs have been split off into a
separate package, |clipkg|_, which must be installed separately in order to use
them.  See `the package's documentation
<http://javaproperties-cli.readthedocs.io>`_ for details.

.. |clipkg| replace:: ``javaproperties-cli``
.. _clipkg: https://github.com/jwodder/javaproperties-cli
