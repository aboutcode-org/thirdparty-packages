Release notes
-------------

### Version 0.9.10

*2021-03-25* 
-- Rename module to debian_inspector
-- Add compat debut module, marked as deprecated
-- Drop support for Python 2
-- Fix version parsing bugs using all new code from @xolox


### Version 0.9.9 

*2021-02-12* -- Relax support for chardet versions
*2021-02-12* -- Add new Contents index parser
*2020-10-28* -- Improve docstrings
*2020-08-03* -- Remove Alpine support (moved to scancode-toolkit)


### Version 0.9.8

*2020-07-07* -- Correct setup.py typo


### Version 0.9.7

*2020-07-07* -- Correct configure script


### Version 0.9.6

*2020-07-07* -- Support parsing Alpine installed db. This is a debian-like file but the keys are case-sensitive 


### Version 0.9.5

*2020-06-09* -- Simplify configure and fix minor bugs


### Version 0.9.4

*2020-04-28* -- Add new DebianCopyright.from_text() method to copyright module.


### Version 0.9.3

*2020-04-20* -- Add support for CodeArchive and minor refactorings.


### Version 0.9.2

*2020-04-17* -- Initial release.


