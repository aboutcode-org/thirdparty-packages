#! /usr/bin/env python
#
# Copyright (c) 2011 SEOmoz
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

'''All of our exceptions'''


class ReppyException(Exception):
    '''Any internal exception'''
    pass

class ContentTooLong(ReppyException):
    '''Robots.txt content is too long.'''
    pass

class ServerError(ReppyException):
    '''When the remote server returns an error'''
    pass

class SSLException(ReppyException):
    '''An SSL error.'''
    pass

class ConnectionException(ReppyException):
    '''A connection error exception.'''
    pass

class MalformedUrl(ReppyException):
    '''An exception for a missing or invalid url or schema.'''
    pass

class ExcessiveRedirects(ReppyException):
    '''A TooManyRedirects error.'''
    pass

class ReadTimeout(ReppyException):
    '''A ReadTimeout error from the HTTP library.'''
    pass

class BadStatusCode(ReppyException):
    '''An exception for 5xx status codes.'''
    pass
