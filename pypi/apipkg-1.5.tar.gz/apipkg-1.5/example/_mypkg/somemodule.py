
from _mypkg.othermodule import OtherClass

class SomeClass:
    pass
