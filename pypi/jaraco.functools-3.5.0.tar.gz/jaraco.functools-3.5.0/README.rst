.. image:: https://img.shields.io/pypi/v/jaraco.functools.svg
   :target: `PyPI link`_

.. image:: https://img.shields.io/pypi/pyversions/jaraco.functools.svg

.. image:: https://img.shields.io/travis/jaraco/jaraco.functools/master.svg
   :target: `PyPI link`_

.. _PyPI link: https://pypi.org/project/jaraco.functools

.. image:: https://github.com/jaraco/jaraco.functools/workflows/tests/badge.svg
   :target: https://github.com/jaraco/jaraco.functools/actions?query=workflow%3A%22tests%22
   :alt: tests

.. image:: https://img.shields.io/badge/code%20style-black-000000.svg
   :target: https://github.com/psf/black
   :alt: Code style: Black

.. image:: https://readthedocs.org/projects/jaracofunctools/badge/?version=latest
   :target: https://jaracofunctools.readthedocs.io/en/latest/?badge=latest

.. image:: https://img.shields.io/badge/skeleton-2021-informational
   :target: https://blog.jaraco.com/skeleton

Additional functools in the spirit of stdlib's functools.
