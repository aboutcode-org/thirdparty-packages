"""
Tests async overrides of commands from their mixins
"""
