Changelog
=========

1.3.1 (2021-08-15)
__________________

* Address ``DeprecationWarning`` re: ``collections.abc`` on Python 3.9
  (`#45 <https://github.com/sloria/tinynetrc/issues/45>`_).
  Thanks `@tirkarthi <https://github.com/tirkarthi>`_ for the PR.

1.3.0 (2018-12-11)
------------------

* Add context manager API (`#4 <https://github.com/sloria/tinynetrc/issues/4>`_).
* Drop support for Python 3.4.
* Test against Python 3.7.

1.2.0 (2018-01-12)
------------------

* Don't error if ``$HOME`` is not set (`#2 <https://github.com/sloria/tinynetrc/issues/2>`_).

1.1.0 (2017-11-04)
------------------

* Add dict-like shorthand syntax.

1.0.0 (2017-11-03)
------------------

* Initial release.
