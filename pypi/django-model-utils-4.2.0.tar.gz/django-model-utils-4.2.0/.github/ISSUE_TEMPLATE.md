## Problem

Explain the problem you encountered.

## Environment

- Django Model Utils version:
- Django version: 
- Python version: 
- Other libraries used, if any:

## Code examples

Give code example that demonstrates the issue, or even better, write new tests that fails because of that issue.
