nltk.classify package
=====================

Submodules
----------

nltk.classify.api module
------------------------

.. automodule:: nltk.classify.api
   :members:
   :undoc-members:
   :show-inheritance:

nltk.classify.decisiontree module
---------------------------------

.. automodule:: nltk.classify.decisiontree
   :members:
   :undoc-members:
   :show-inheritance:

nltk.classify.maxent module
---------------------------

.. automodule:: nltk.classify.maxent
   :members:
   :undoc-members:
   :show-inheritance:

nltk.classify.megam module
--------------------------

.. automodule:: nltk.classify.megam
   :members:
   :undoc-members:
   :show-inheritance:

nltk.classify.naivebayes module
-------------------------------

.. automodule:: nltk.classify.naivebayes
   :members:
   :undoc-members:
   :show-inheritance:

nltk.classify.positivenaivebayes module
---------------------------------------

.. automodule:: nltk.classify.positivenaivebayes
   :members:
   :undoc-members:
   :show-inheritance:

nltk.classify.rte\_classify module
----------------------------------

.. automodule:: nltk.classify.rte_classify
   :members:
   :undoc-members:
   :show-inheritance:

nltk.classify.scikitlearn module
--------------------------------

.. automodule:: nltk.classify.scikitlearn
   :members:
   :undoc-members:
   :show-inheritance:

nltk.classify.senna module
--------------------------

.. automodule:: nltk.classify.senna
   :members:
   :undoc-members:
   :show-inheritance:

nltk.classify.svm module
------------------------

.. automodule:: nltk.classify.svm
   :members:
   :undoc-members:
   :show-inheritance:

nltk.classify.tadm module
-------------------------

.. automodule:: nltk.classify.tadm
   :members:
   :undoc-members:
   :show-inheritance:

nltk.classify.textcat module
----------------------------

.. automodule:: nltk.classify.textcat
   :members:
   :undoc-members:
   :show-inheritance:

nltk.classify.util module
-------------------------

.. automodule:: nltk.classify.util
   :members:
   :undoc-members:
   :show-inheritance:

nltk.classify.weka module
-------------------------

.. automodule:: nltk.classify.weka
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: nltk.classify
   :members:
   :undoc-members:
   :show-inheritance:
