nltk.tokenize package
=====================

Submodules
----------

nltk.tokenize.api module
------------------------

.. automodule:: nltk.tokenize.api
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tokenize.casual module
---------------------------

.. automodule:: nltk.tokenize.casual
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tokenize.destructive module
--------------------------------

.. automodule:: nltk.tokenize.destructive
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tokenize.legality\_principle module
----------------------------------------

.. automodule:: nltk.tokenize.legality_principle
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tokenize.mwe module
------------------------

.. automodule:: nltk.tokenize.mwe
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tokenize.nist module
-------------------------

.. automodule:: nltk.tokenize.nist
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tokenize.punkt module
--------------------------

.. automodule:: nltk.tokenize.punkt
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tokenize.regexp module
---------------------------

.. automodule:: nltk.tokenize.regexp
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tokenize.repp module
-------------------------

.. automodule:: nltk.tokenize.repp
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tokenize.sexpr module
--------------------------

.. automodule:: nltk.tokenize.sexpr
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tokenize.simple module
---------------------------

.. automodule:: nltk.tokenize.simple
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tokenize.sonority\_sequencing module
-----------------------------------------

.. automodule:: nltk.tokenize.sonority_sequencing
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tokenize.stanford module
-----------------------------

.. automodule:: nltk.tokenize.stanford
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tokenize.stanford\_segmenter module
----------------------------------------

.. automodule:: nltk.tokenize.stanford_segmenter
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tokenize.texttiling module
-------------------------------

.. automodule:: nltk.tokenize.texttiling
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tokenize.toktok module
---------------------------

.. automodule:: nltk.tokenize.toktok
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tokenize.treebank module
-----------------------------

.. automodule:: nltk.tokenize.treebank
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tokenize.util module
-------------------------

.. automodule:: nltk.tokenize.util
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: nltk.tokenize
   :members:
   :undoc-members:
   :show-inheritance:
