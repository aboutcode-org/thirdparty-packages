nltk.draw package
=================

Submodules
----------

nltk.draw.cfg module
--------------------

.. automodule:: nltk.draw.cfg
   :members:
   :undoc-members:
   :show-inheritance:

nltk.draw.dispersion module
---------------------------

.. automodule:: nltk.draw.dispersion
   :members:
   :undoc-members:
   :show-inheritance:

nltk.draw.table module
----------------------

.. automodule:: nltk.draw.table
   :members:
   :undoc-members:
   :show-inheritance:

nltk.draw.tree module
---------------------

.. automodule:: nltk.draw.tree
   :members:
   :undoc-members:
   :show-inheritance:

nltk.draw.util module
---------------------

.. automodule:: nltk.draw.util
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: nltk.draw
   :members:
   :undoc-members:
   :show-inheritance:
