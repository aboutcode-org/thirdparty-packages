nltk.inference package
======================

Submodules
----------

nltk.inference.api module
-------------------------

.. automodule:: nltk.inference.api
   :members:
   :undoc-members:
   :show-inheritance:

nltk.inference.discourse module
-------------------------------

.. automodule:: nltk.inference.discourse
   :members:
   :undoc-members:
   :show-inheritance:

nltk.inference.mace module
--------------------------

.. automodule:: nltk.inference.mace
   :members:
   :undoc-members:
   :show-inheritance:

nltk.inference.nonmonotonic module
----------------------------------

.. automodule:: nltk.inference.nonmonotonic
   :members:
   :undoc-members:
   :show-inheritance:

nltk.inference.prover9 module
-----------------------------

.. automodule:: nltk.inference.prover9
   :members:
   :undoc-members:
   :show-inheritance:

nltk.inference.resolution module
--------------------------------

.. automodule:: nltk.inference.resolution
   :members:
   :undoc-members:
   :show-inheritance:

nltk.inference.tableau module
-----------------------------

.. automodule:: nltk.inference.tableau
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: nltk.inference
   :members:
   :undoc-members:
   :show-inheritance:
