nltk.translate package
======================

Submodules
----------

nltk.translate.api module
-------------------------

.. automodule:: nltk.translate.api
   :members:
   :undoc-members:
   :show-inheritance:

nltk.translate.bleu\_score module
---------------------------------

.. automodule:: nltk.translate.bleu_score
   :members:
   :undoc-members:
   :show-inheritance:

nltk.translate.chrf\_score module
---------------------------------

.. automodule:: nltk.translate.chrf_score
   :members:
   :undoc-members:
   :show-inheritance:

nltk.translate.gale\_church module
----------------------------------

.. automodule:: nltk.translate.gale_church
   :members:
   :undoc-members:
   :show-inheritance:

nltk.translate.gdfa module
--------------------------

.. automodule:: nltk.translate.gdfa
   :members:
   :undoc-members:
   :show-inheritance:

nltk.translate.gleu\_score module
---------------------------------

.. automodule:: nltk.translate.gleu_score
   :members:
   :undoc-members:
   :show-inheritance:

nltk.translate.ibm1 module
--------------------------

.. automodule:: nltk.translate.ibm1
   :members:
   :undoc-members:
   :show-inheritance:

nltk.translate.ibm2 module
--------------------------

.. automodule:: nltk.translate.ibm2
   :members:
   :undoc-members:
   :show-inheritance:

nltk.translate.ibm3 module
--------------------------

.. automodule:: nltk.translate.ibm3
   :members:
   :undoc-members:
   :show-inheritance:

nltk.translate.ibm4 module
--------------------------

.. automodule:: nltk.translate.ibm4
   :members:
   :undoc-members:
   :show-inheritance:

nltk.translate.ibm5 module
--------------------------

.. automodule:: nltk.translate.ibm5
   :members:
   :undoc-members:
   :show-inheritance:

nltk.translate.ibm\_model module
--------------------------------

.. automodule:: nltk.translate.ibm_model
   :members:
   :undoc-members:
   :show-inheritance:

nltk.translate.meteor\_score module
-----------------------------------

.. automodule:: nltk.translate.meteor_score
   :members:
   :undoc-members:
   :show-inheritance:

nltk.translate.metrics module
-----------------------------

.. automodule:: nltk.translate.metrics
   :members:
   :undoc-members:
   :show-inheritance:

nltk.translate.nist\_score module
---------------------------------

.. automodule:: nltk.translate.nist_score
   :members:
   :undoc-members:
   :show-inheritance:

nltk.translate.phrase\_based module
-----------------------------------

.. automodule:: nltk.translate.phrase_based
   :members:
   :undoc-members:
   :show-inheritance:

nltk.translate.ribes\_score module
----------------------------------

.. automodule:: nltk.translate.ribes_score
   :members:
   :undoc-members:
   :show-inheritance:

nltk.translate.stack\_decoder module
------------------------------------

.. automodule:: nltk.translate.stack_decoder
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: nltk.translate
   :members:
   :undoc-members:
   :show-inheritance:
