nltk.sem package
================

Submodules
----------

nltk.sem.boxer module
---------------------

.. automodule:: nltk.sem.boxer
   :members:
   :undoc-members:
   :show-inheritance:

nltk.sem.chat80 module
----------------------

.. automodule:: nltk.sem.chat80
   :members:
   :undoc-members:
   :show-inheritance:

nltk.sem.cooper\_storage module
-------------------------------

.. automodule:: nltk.sem.cooper_storage
   :members:
   :undoc-members:
   :show-inheritance:

nltk.sem.drt module
-------------------

.. automodule:: nltk.sem.drt
   :members:
   :undoc-members:
   :show-inheritance:

nltk.sem.drt\_glue\_demo module
-------------------------------

.. automodule:: nltk.sem.drt_glue_demo
   :members:
   :undoc-members:
   :show-inheritance:

nltk.sem.evaluate module
------------------------

.. automodule:: nltk.sem.evaluate
   :members:
   :undoc-members:
   :show-inheritance:

nltk.sem.glue module
--------------------

.. automodule:: nltk.sem.glue
   :members:
   :undoc-members:
   :show-inheritance:

nltk.sem.hole module
--------------------

.. automodule:: nltk.sem.hole
   :members:
   :undoc-members:
   :show-inheritance:

nltk.sem.lfg module
-------------------

.. automodule:: nltk.sem.lfg
   :members:
   :undoc-members:
   :show-inheritance:

nltk.sem.linearlogic module
---------------------------

.. automodule:: nltk.sem.linearlogic
   :members:
   :undoc-members:
   :show-inheritance:

nltk.sem.logic module
---------------------

.. automodule:: nltk.sem.logic
   :members:
   :undoc-members:
   :show-inheritance:

nltk.sem.relextract module
--------------------------

.. automodule:: nltk.sem.relextract
   :members:
   :undoc-members:
   :show-inheritance:

nltk.sem.skolemize module
-------------------------

.. automodule:: nltk.sem.skolemize
   :members:
   :undoc-members:
   :show-inheritance:

nltk.sem.util module
--------------------

.. automodule:: nltk.sem.util
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: nltk.sem
   :members:
   :undoc-members:
   :show-inheritance:
