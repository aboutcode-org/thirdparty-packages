nltk.test package
=================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   nltk.test.unit

Submodules
----------

nltk.test.all module
--------------------

.. automodule:: nltk.test.all
   :members:
   :undoc-members:
   :show-inheritance:

nltk.test.childes\_fixt module
------------------------------

.. automodule:: nltk.test.childes_fixt
   :members:
   :undoc-members:
   :show-inheritance:

nltk.test.classify\_fixt module
-------------------------------

.. automodule:: nltk.test.classify_fixt
   :members:
   :undoc-members:
   :show-inheritance:

nltk.test.conftest module
-------------------------

.. automodule:: nltk.test.conftest
   :members:
   :undoc-members:
   :show-inheritance:

nltk.test.discourse\_fixt module
--------------------------------

.. automodule:: nltk.test.discourse_fixt
   :members:
   :undoc-members:
   :show-inheritance:

nltk.test.gensim\_fixt module
-----------------------------

.. automodule:: nltk.test.gensim_fixt
   :members:
   :undoc-members:
   :show-inheritance:

nltk.test.gluesemantics\_malt\_fixt module
------------------------------------------

.. automodule:: nltk.test.gluesemantics_malt_fixt
   :members:
   :undoc-members:
   :show-inheritance:

nltk.test.inference\_fixt module
--------------------------------

.. automodule:: nltk.test.inference_fixt
   :members:
   :undoc-members:
   :show-inheritance:

nltk.test.nonmonotonic\_fixt module
-----------------------------------

.. automodule:: nltk.test.nonmonotonic_fixt
   :members:
   :undoc-members:
   :show-inheritance:

nltk.test.portuguese\_en\_fixt module
-------------------------------------

.. automodule:: nltk.test.portuguese_en_fixt
   :members:
   :undoc-members:
   :show-inheritance:

nltk.test.probability\_fixt module
----------------------------------

.. automodule:: nltk.test.probability_fixt
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: nltk.test
   :members:
   :undoc-members:
   :show-inheritance:
