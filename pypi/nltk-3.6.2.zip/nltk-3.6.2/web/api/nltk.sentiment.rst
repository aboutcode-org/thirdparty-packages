nltk.sentiment package
======================

Submodules
----------

nltk.sentiment.sentiment\_analyzer module
-----------------------------------------

.. automodule:: nltk.sentiment.sentiment_analyzer
   :members:
   :undoc-members:
   :show-inheritance:

nltk.sentiment.util module
--------------------------

.. automodule:: nltk.sentiment.util
   :members:
   :undoc-members:
   :show-inheritance:

nltk.sentiment.vader module
---------------------------

.. automodule:: nltk.sentiment.vader
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: nltk.sentiment
   :members:
   :undoc-members:
   :show-inheritance:
