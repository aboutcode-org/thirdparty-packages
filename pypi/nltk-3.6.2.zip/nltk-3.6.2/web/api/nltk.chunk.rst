nltk.chunk package
==================

Submodules
----------

nltk.chunk.api module
---------------------

.. automodule:: nltk.chunk.api
   :members:
   :undoc-members:
   :show-inheritance:

nltk.chunk.named\_entity module
-------------------------------

.. automodule:: nltk.chunk.named_entity
   :members:
   :undoc-members:
   :show-inheritance:

nltk.chunk.regexp module
------------------------

.. automodule:: nltk.chunk.regexp
   :members:
   :undoc-members:
   :show-inheritance:

nltk.chunk.util module
----------------------

.. automodule:: nltk.chunk.util
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: nltk.chunk
   :members:
   :undoc-members:
   :show-inheritance:
