nltk.tbl package
================

Submodules
----------

nltk.tbl.api module
-------------------

.. automodule:: nltk.tbl.api
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tbl.demo module
--------------------

.. automodule:: nltk.tbl.demo
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tbl.erroranalysis module
-----------------------------

.. automodule:: nltk.tbl.erroranalysis
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tbl.feature module
-----------------------

.. automodule:: nltk.tbl.feature
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tbl.rule module
--------------------

.. automodule:: nltk.tbl.rule
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tbl.template module
------------------------

.. automodule:: nltk.tbl.template
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: nltk.tbl
   :members:
   :undoc-members:
   :show-inheritance:
