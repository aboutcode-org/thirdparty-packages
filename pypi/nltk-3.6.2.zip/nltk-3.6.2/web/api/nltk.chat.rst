nltk.chat package
=================

Submodules
----------

nltk.chat.eliza module
----------------------

.. automodule:: nltk.chat.eliza
   :members:
   :undoc-members:
   :show-inheritance:

nltk.chat.iesha module
----------------------

.. automodule:: nltk.chat.iesha
   :members:
   :undoc-members:
   :show-inheritance:

nltk.chat.rude module
---------------------

.. automodule:: nltk.chat.rude
   :members:
   :undoc-members:
   :show-inheritance:

nltk.chat.suntsu module
-----------------------

.. automodule:: nltk.chat.suntsu
   :members:
   :undoc-members:
   :show-inheritance:

nltk.chat.util module
---------------------

.. automodule:: nltk.chat.util
   :members:
   :undoc-members:
   :show-inheritance:

nltk.chat.zen module
--------------------

.. automodule:: nltk.chat.zen
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: nltk.chat
   :members:
   :undoc-members:
   :show-inheritance:
