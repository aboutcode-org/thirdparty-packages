nltk.corpus.reader package
==========================

Submodules
----------

nltk.corpus.reader.aligned module
---------------------------------

.. automodule:: nltk.corpus.reader.aligned
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.api module
-----------------------------

.. automodule:: nltk.corpus.reader.api
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.bnc module
-----------------------------

.. automodule:: nltk.corpus.reader.bnc
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.bracket\_parse module
----------------------------------------

.. automodule:: nltk.corpus.reader.bracket_parse
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.categorized\_sents module
--------------------------------------------

.. automodule:: nltk.corpus.reader.categorized_sents
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.chasen module
--------------------------------

.. automodule:: nltk.corpus.reader.chasen
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.childes module
---------------------------------

.. automodule:: nltk.corpus.reader.childes
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.chunked module
---------------------------------

.. automodule:: nltk.corpus.reader.chunked
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.cmudict module
---------------------------------

.. automodule:: nltk.corpus.reader.cmudict
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.comparative\_sents module
--------------------------------------------

.. automodule:: nltk.corpus.reader.comparative_sents
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.conll module
-------------------------------

.. automodule:: nltk.corpus.reader.conll
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.crubadan module
----------------------------------

.. automodule:: nltk.corpus.reader.crubadan
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.dependency module
------------------------------------

.. automodule:: nltk.corpus.reader.dependency
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.framenet module
----------------------------------

.. automodule:: nltk.corpus.reader.framenet
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.ieer module
------------------------------

.. automodule:: nltk.corpus.reader.ieer
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.indian module
--------------------------------

.. automodule:: nltk.corpus.reader.indian
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.ipipan module
--------------------------------

.. automodule:: nltk.corpus.reader.ipipan
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.knbc module
------------------------------

.. automodule:: nltk.corpus.reader.knbc
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.lin module
-----------------------------

.. automodule:: nltk.corpus.reader.lin
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.mte module
-----------------------------

.. automodule:: nltk.corpus.reader.mte
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.nkjp module
------------------------------

.. automodule:: nltk.corpus.reader.nkjp
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.nombank module
---------------------------------

.. automodule:: nltk.corpus.reader.nombank
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.nps\_chat module
-----------------------------------

.. automodule:: nltk.corpus.reader.nps_chat
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.opinion\_lexicon module
------------------------------------------

.. automodule:: nltk.corpus.reader.opinion_lexicon
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.panlex\_lite module
--------------------------------------

.. automodule:: nltk.corpus.reader.panlex_lite
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.panlex\_swadesh module
-----------------------------------------

.. automodule:: nltk.corpus.reader.panlex_swadesh
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.pl196x module
--------------------------------

.. automodule:: nltk.corpus.reader.pl196x
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.plaintext module
-----------------------------------

.. automodule:: nltk.corpus.reader.plaintext
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.ppattach module
----------------------------------

.. automodule:: nltk.corpus.reader.ppattach
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.propbank module
----------------------------------

.. automodule:: nltk.corpus.reader.propbank
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.pros\_cons module
------------------------------------

.. automodule:: nltk.corpus.reader.pros_cons
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.reviews module
---------------------------------

.. automodule:: nltk.corpus.reader.reviews
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.rte module
-----------------------------

.. automodule:: nltk.corpus.reader.rte
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.semcor module
--------------------------------

.. automodule:: nltk.corpus.reader.semcor
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.senseval module
----------------------------------

.. automodule:: nltk.corpus.reader.senseval
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.sentiwordnet module
--------------------------------------

.. automodule:: nltk.corpus.reader.sentiwordnet
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.sinica\_treebank module
------------------------------------------

.. automodule:: nltk.corpus.reader.sinica_treebank
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.string\_category module
------------------------------------------

.. automodule:: nltk.corpus.reader.string_category
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.switchboard module
-------------------------------------

.. automodule:: nltk.corpus.reader.switchboard
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.tagged module
--------------------------------

.. automodule:: nltk.corpus.reader.tagged
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.timit module
-------------------------------

.. automodule:: nltk.corpus.reader.timit
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.toolbox module
---------------------------------

.. automodule:: nltk.corpus.reader.toolbox
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.twitter module
---------------------------------

.. automodule:: nltk.corpus.reader.twitter
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.udhr module
------------------------------

.. automodule:: nltk.corpus.reader.udhr
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.util module
------------------------------

.. automodule:: nltk.corpus.reader.util
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.verbnet module
---------------------------------

.. automodule:: nltk.corpus.reader.verbnet
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.wordlist module
----------------------------------

.. automodule:: nltk.corpus.reader.wordlist
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.wordnet module
---------------------------------

.. automodule:: nltk.corpus.reader.wordnet
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.xmldocs module
---------------------------------

.. automodule:: nltk.corpus.reader.xmldocs
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.reader.ycoe module
------------------------------

.. automodule:: nltk.corpus.reader.ycoe
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: nltk.corpus.reader
   :members:
   :undoc-members:
   :show-inheritance:
