nltk.stem package
=================

Submodules
----------

nltk.stem.api module
--------------------

.. automodule:: nltk.stem.api
   :members:
   :undoc-members:
   :show-inheritance:

nltk.stem.arlstem module
------------------------

.. automodule:: nltk.stem.arlstem
   :members:
   :undoc-members:
   :show-inheritance:

nltk.stem.arlstem2 module
-------------------------

.. automodule:: nltk.stem.arlstem2
   :members:
   :undoc-members:
   :show-inheritance:

nltk.stem.cistem module
-----------------------

.. automodule:: nltk.stem.cistem
   :members:
   :undoc-members:
   :show-inheritance:

nltk.stem.isri module
---------------------

.. automodule:: nltk.stem.isri
   :members:
   :undoc-members:
   :show-inheritance:

nltk.stem.lancaster module
--------------------------

.. automodule:: nltk.stem.lancaster
   :members:
   :undoc-members:
   :show-inheritance:

nltk.stem.porter module
-----------------------

.. automodule:: nltk.stem.porter
   :members:
   :undoc-members:
   :show-inheritance:

nltk.stem.regexp module
-----------------------

.. automodule:: nltk.stem.regexp
   :members:
   :undoc-members:
   :show-inheritance:

nltk.stem.rslp module
---------------------

.. automodule:: nltk.stem.rslp
   :members:
   :undoc-members:
   :show-inheritance:

nltk.stem.snowball module
-------------------------

.. automodule:: nltk.stem.snowball
   :members:
   :undoc-members:
   :show-inheritance:

nltk.stem.util module
---------------------

.. automodule:: nltk.stem.util
   :members:
   :undoc-members:
   :show-inheritance:

nltk.stem.wordnet module
------------------------

.. automodule:: nltk.stem.wordnet
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: nltk.stem
   :members:
   :undoc-members:
   :show-inheritance:
