nltk.ccg package
================

Submodules
----------

nltk.ccg.api module
-------------------

.. automodule:: nltk.ccg.api
   :members:
   :undoc-members:
   :show-inheritance:

nltk.ccg.chart module
---------------------

.. automodule:: nltk.ccg.chart
   :members:
   :undoc-members:
   :show-inheritance:

nltk.ccg.combinator module
--------------------------

.. automodule:: nltk.ccg.combinator
   :members:
   :undoc-members:
   :show-inheritance:

nltk.ccg.lexicon module
-----------------------

.. automodule:: nltk.ccg.lexicon
   :members:
   :undoc-members:
   :show-inheritance:

nltk.ccg.logic module
---------------------

.. automodule:: nltk.ccg.logic
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: nltk.ccg
   :members:
   :undoc-members:
   :show-inheritance:
