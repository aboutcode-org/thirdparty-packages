nltk.misc package
=================

Submodules
----------

nltk.misc.babelfish module
--------------------------

.. automodule:: nltk.misc.babelfish
   :members:
   :undoc-members:
   :show-inheritance:

nltk.misc.chomsky module
------------------------

.. automodule:: nltk.misc.chomsky
   :members:
   :undoc-members:
   :show-inheritance:

nltk.misc.minimalset module
---------------------------

.. automodule:: nltk.misc.minimalset
   :members:
   :undoc-members:
   :show-inheritance:

nltk.misc.sort module
---------------------

.. automodule:: nltk.misc.sort
   :members:
   :undoc-members:
   :show-inheritance:

nltk.misc.wordfinder module
---------------------------

.. automodule:: nltk.misc.wordfinder
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: nltk.misc
   :members:
   :undoc-members:
   :show-inheritance:
