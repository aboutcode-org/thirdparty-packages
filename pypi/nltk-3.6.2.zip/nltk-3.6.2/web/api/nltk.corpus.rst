nltk.corpus package
===================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   nltk.corpus.reader

Submodules
----------

nltk.corpus.europarl\_raw module
--------------------------------

.. automodule:: nltk.corpus.europarl_raw
   :members:
   :undoc-members:
   :show-inheritance:

nltk.corpus.util module
-----------------------

.. automodule:: nltk.corpus.util
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: nltk.corpus
   :members:
   :undoc-members:
   :show-inheritance:
