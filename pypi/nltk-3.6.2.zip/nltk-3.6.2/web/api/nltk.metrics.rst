nltk.metrics package
====================

Submodules
----------

nltk.metrics.agreement module
-----------------------------

.. automodule:: nltk.metrics.agreement
   :members:
   :undoc-members:
   :show-inheritance:

nltk.metrics.aline module
-------------------------

.. automodule:: nltk.metrics.aline
   :members:
   :undoc-members:
   :show-inheritance:

nltk.metrics.association module
-------------------------------

.. automodule:: nltk.metrics.association
   :members:
   :undoc-members:
   :show-inheritance:

nltk.metrics.confusionmatrix module
-----------------------------------

.. automodule:: nltk.metrics.confusionmatrix
   :members:
   :undoc-members:
   :show-inheritance:

nltk.metrics.distance module
----------------------------

.. automodule:: nltk.metrics.distance
   :members:
   :undoc-members:
   :show-inheritance:

nltk.metrics.paice module
-------------------------

.. automodule:: nltk.metrics.paice
   :members:
   :undoc-members:
   :show-inheritance:

nltk.metrics.scores module
--------------------------

.. automodule:: nltk.metrics.scores
   :members:
   :undoc-members:
   :show-inheritance:

nltk.metrics.segmentation module
--------------------------------

.. automodule:: nltk.metrics.segmentation
   :members:
   :undoc-members:
   :show-inheritance:

nltk.metrics.spearman module
----------------------------

.. automodule:: nltk.metrics.spearman
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: nltk.metrics
   :members:
   :undoc-members:
   :show-inheritance:
