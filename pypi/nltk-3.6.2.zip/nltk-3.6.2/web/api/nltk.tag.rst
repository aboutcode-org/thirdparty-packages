nltk.tag package
================

Submodules
----------

nltk.tag.api module
-------------------

.. automodule:: nltk.tag.api
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tag.brill module
---------------------

.. automodule:: nltk.tag.brill
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tag.brill\_trainer module
------------------------------

.. automodule:: nltk.tag.brill_trainer
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tag.crf module
-------------------

.. automodule:: nltk.tag.crf
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tag.hmm module
-------------------

.. automodule:: nltk.tag.hmm
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tag.hunpos module
----------------------

.. automodule:: nltk.tag.hunpos
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tag.mapping module
-----------------------

.. automodule:: nltk.tag.mapping
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tag.perceptron module
--------------------------

.. automodule:: nltk.tag.perceptron
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tag.senna module
---------------------

.. automodule:: nltk.tag.senna
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tag.sequential module
--------------------------

.. automodule:: nltk.tag.sequential
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tag.stanford module
------------------------

.. automodule:: nltk.tag.stanford
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tag.tnt module
-------------------

.. automodule:: nltk.tag.tnt
   :members:
   :undoc-members:
   :show-inheritance:

nltk.tag.util module
--------------------

.. automodule:: nltk.tag.util
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: nltk.tag
   :members:
   :undoc-members:
   :show-inheritance:
