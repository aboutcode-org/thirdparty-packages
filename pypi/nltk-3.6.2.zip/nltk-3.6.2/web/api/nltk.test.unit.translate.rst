nltk.test.unit.translate package
================================

Submodules
----------

nltk.test.unit.translate.test\_bleu module
------------------------------------------

.. automodule:: nltk.test.unit.translate.test_bleu
   :members:
   :undoc-members:
   :show-inheritance:

nltk.test.unit.translate.test\_gdfa module
------------------------------------------

.. automodule:: nltk.test.unit.translate.test_gdfa
   :members:
   :undoc-members:
   :show-inheritance:

nltk.test.unit.translate.test\_ibm1 module
------------------------------------------

.. automodule:: nltk.test.unit.translate.test_ibm1
   :members:
   :undoc-members:
   :show-inheritance:

nltk.test.unit.translate.test\_ibm2 module
------------------------------------------

.. automodule:: nltk.test.unit.translate.test_ibm2
   :members:
   :undoc-members:
   :show-inheritance:

nltk.test.unit.translate.test\_ibm3 module
------------------------------------------

.. automodule:: nltk.test.unit.translate.test_ibm3
   :members:
   :undoc-members:
   :show-inheritance:

nltk.test.unit.translate.test\_ibm4 module
------------------------------------------

.. automodule:: nltk.test.unit.translate.test_ibm4
   :members:
   :undoc-members:
   :show-inheritance:

nltk.test.unit.translate.test\_ibm5 module
------------------------------------------

.. automodule:: nltk.test.unit.translate.test_ibm5
   :members:
   :undoc-members:
   :show-inheritance:

nltk.test.unit.translate.test\_ibm\_model module
------------------------------------------------

.. automodule:: nltk.test.unit.translate.test_ibm_model
   :members:
   :undoc-members:
   :show-inheritance:

nltk.test.unit.translate.test\_meteor module
--------------------------------------------

.. automodule:: nltk.test.unit.translate.test_meteor
   :members:
   :undoc-members:
   :show-inheritance:

nltk.test.unit.translate.test\_nist module
------------------------------------------

.. automodule:: nltk.test.unit.translate.test_nist
   :members:
   :undoc-members:
   :show-inheritance:

nltk.test.unit.translate.test\_stack\_decoder module
----------------------------------------------------

.. automodule:: nltk.test.unit.translate.test_stack_decoder
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: nltk.test.unit.translate
   :members:
   :undoc-members:
   :show-inheritance:
