nltk.app package
================

Submodules
----------

nltk.app.chartparser\_app module
--------------------------------

.. automodule:: nltk.app.chartparser_app
   :members:
   :undoc-members:
   :show-inheritance:

nltk.app.chunkparser\_app module
--------------------------------

.. automodule:: nltk.app.chunkparser_app
   :members:
   :undoc-members:
   :show-inheritance:

nltk.app.collocations\_app module
---------------------------------

.. automodule:: nltk.app.collocations_app
   :members:
   :undoc-members:
   :show-inheritance:

nltk.app.concordance\_app module
--------------------------------

.. automodule:: nltk.app.concordance_app
   :members:
   :undoc-members:
   :show-inheritance:

nltk.app.nemo\_app module
-------------------------

.. automodule:: nltk.app.nemo_app
   :members:
   :undoc-members:
   :show-inheritance:

nltk.app.rdparser\_app module
-----------------------------

.. automodule:: nltk.app.rdparser_app
   :members:
   :undoc-members:
   :show-inheritance:

nltk.app.srparser\_app module
-----------------------------

.. automodule:: nltk.app.srparser_app
   :members:
   :undoc-members:
   :show-inheritance:

nltk.app.wordfreq\_app module
-----------------------------

.. automodule:: nltk.app.wordfreq_app
   :members:
   :undoc-members:
   :show-inheritance:

nltk.app.wordnet\_app module
----------------------------

.. automodule:: nltk.app.wordnet_app
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: nltk.app
   :members:
   :undoc-members:
   :show-inheritance:
