.. _index:

=====================================================
 django-guardian - per object permissions for Django
=====================================================

:Date: |today|
:Version: |version|

**Documentation**:

.. image:: https://secure.travis-ci.org/django-guardian/django-guardian.png?branch=master
  :target: http://travis-ci.org/django-guardian/django-guardian

.. toctree::
    :maxdepth: 2

    overview
    installation
    configuration
    userguide/index
    api/index
    develop/index
    license


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

