.. _api:

API Reference
=============

.. toctree::
   :maxdepth: 2

   guardian.admin
   guardian.backends
   guardian.core
   guardian.decorators
   guardian.forms
   guardian.management.commands
   guardian.managers
   guardian.mixins
   guardian.models
   guardian.shortcuts
   guardian.utils
   
   guardian.templatetags.guardian_tags

