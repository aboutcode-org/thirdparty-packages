.. _api-core:

Core
====

.. automodule:: guardian.core


ObjectPermissionChecker
-----------------------

.. autoclass:: guardian.core.ObjectPermissionChecker
   :members:

