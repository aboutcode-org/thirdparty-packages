.. _guide:

User Guide
==========

.. toctree::
    :maxdepth: 2

    example_project
    assign
    check
    remove
    admin-integration
    custom-user-model
    performance
    caveats
    
