# Empty __init__.py to allow importing of `ansible_test._util.target.common` under Python 2.x.
# This allows the ansible-test entry point to report supported Python versions before exiting.
