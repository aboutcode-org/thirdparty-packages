All documents in this Repository are licensed by contributors
under both the the [W3C Test Suite License](http://www.w3.org/Consortium/Legal/2008/04-testsuite-license) and 
[W3C Software and Document License](https://www.w3.org/Consortium/Legal/copyright-software).

