from rdflib import parser, plugin, serializer

assert plugin
assert serializer
assert parser
import json
