# SPDX-License-Identifier: MIT
# Copyright (c)  Jannis Gebauer and others
# Originally from https://github.com/pyupio/dparse/
# Now maintained at https://github.com/nexB/dparse2

# Originally from
# __author__ = """Jannis Gebauer"""
# __email__ = 'support@pyup.io'
# __version__ = '0.5.2a'

from dparse2.parser import parse  # noqa
