from time import sleep
from unittest import TestCase


class Delta1(TestCase):
    def test_delta0(self):
        sleep(5)
        assert True

    def test_delta1(self):
        sleep(5)
        assert True

    def test_delta2(self):
        sleep(5)
        assert True

    def test_delta3(self):
        sleep(5)
        assert True

    def test_delta4(self):
        sleep(5)
        assert True

    def test_delta5(self):
        sleep(5)
        assert True

    def test_delta6(self):
        sleep(5)
        assert True

    def test_delta7(self):
        sleep(5)
        assert True

    def test_delta8(self):
        sleep(5)
        assert True

    def test_delta9(self):
        sleep(5)
        assert True


class Delta2(TestCase):
    def test_delta0(self):
        sleep(5)
        assert True

    def test_delta1(self):
        sleep(5)
        assert True

    def test_delta2(self):
        sleep(5)
        assert True

    def test_delta3(self):
        sleep(5)
        assert True

    def test_delta4(self):
        sleep(5)
        assert True

    def test_delta5(self):
        sleep(5)
        assert True

    def test_delta6(self):
        sleep(5)
        assert True

    def test_delta7(self):
        sleep(5)
        assert True

    def test_delta8(self):
        sleep(5)
        assert True

    def test_delta9(self):
        sleep(5)
        assert True
