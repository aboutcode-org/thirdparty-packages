==========================================================
 Async Amazon SQS Client - ``kombu.asynchronous.aws.sqs``
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.asynchronous.aws.sqs

.. automodule:: kombu.asynchronous.aws.sqs
    :members:
    :undoc-members:
