==========================================================
 SQS Queues - ``kombu.asynchronous.aws.sqs.queue``
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.asynchronous.aws.sqs.queue

.. automodule:: kombu.asynchronous.aws.sqs.queue
    :members:
    :undoc-members:
