==========================================================
 Async I/O Selectors - ``kombu.utils.eventio``
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.utils.eventio

.. automodule:: kombu.utils.eventio
    :members:
    :undoc-members:
