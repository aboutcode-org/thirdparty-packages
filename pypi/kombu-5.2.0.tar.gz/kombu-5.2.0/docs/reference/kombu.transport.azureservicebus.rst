==================================================================
 Azure Service Bus Transport - ``kombu.transport.azureservicebus``
==================================================================

.. currentmodule:: kombu.transport.azureservicebus

.. automodule:: kombu.transport.azureservicebus

    .. contents::
        :local:

    Transport
    ---------

    .. autoclass:: Transport
        :members:
        :undoc-members:

    Channel
    -------

    .. autoclass:: Channel
        :members:
        :undoc-members:
