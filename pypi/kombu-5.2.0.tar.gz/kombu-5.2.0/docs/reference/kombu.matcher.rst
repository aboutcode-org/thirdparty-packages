==============================================
 Pattern matching registry - ``kombu.matcher``
==============================================

.. contents::
    :local:
.. currentmodule:: kombu.matcher

.. automodule:: kombu.matcher
    :members:
    :undoc-members:
