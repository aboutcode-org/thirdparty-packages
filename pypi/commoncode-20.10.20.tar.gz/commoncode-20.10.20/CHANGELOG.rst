Release notes
-------------
### Version 20.10.08

*2020-10-08* -- Add support for both python 2 + 3
*2020-10-08* -- Add CI support for python 2 + 3

### Version 20.10

* Minimal fixes needed for proper release

### Version 20.09.30

*2020-09-25* -- Update to PEP 517/518 development practices
*2020-09-25* -- Add some minimal documentation

### Version 20.09

*2020-09-24* -- Initial release.
