class OtherClass:
    pass
