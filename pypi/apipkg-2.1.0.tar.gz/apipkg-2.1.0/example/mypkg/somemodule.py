from __mypkg.othermodule import OtherClass  # NOQA: F401


class SomeClass:
    pass
