INSTALLED_APPS = ["widget_tweaks"]

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
    },
]

SECRET_KEY = "spam-eggs"
