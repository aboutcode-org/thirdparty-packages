Changelog
=========

v21.6.14 - 2021-06-14
----------------------

Added
~~~~~

- Switch to calver for package versioning to better convey the currency of the
  bundled data.

- Include https://scancode-licensedb.aboutcode.org/ licenses list with
  ScanCode (v21.6.7) and SPDX licenses (v3.13) keys. Add new functions to
  create Licensing using these licenses as LicenseSymbol.

- Add new License.dedup() method to deduplicate and simplify license expressions
  without over simplifying.

- Add new License.validate() method to return a new ExpressionInfo object with
  details on a license expression validation.


Changed
~~~~~~~
- Drop support for Python 2.
- Adopt the project skeleton from https://github.com/nexB/skeleton
  and its new configure script


v1.2 - 2019-11-14
------------------
Added
~~~~~
- Add ability to render WITH expression wrapped in parenthesis

Fixes
~~~~~
- Fix anomalous backslashes in strings

Changed
~~~~~~~
- Update the thirdparty directory structure.


v1.0 - 2019-10-16
------------------
Added
~~~~~
- New version of boolean.py library
- Add ability to leave license expressions unsorted when simplifying

Changed
~~~~~~~
- updated travis CI settings


v0.999 - 2019-04-29
--------------------
- Initial release
- license-expression is small utility library to parse, compare and
  simplify and normalize license expressions.

