Welcome to |project| documentation!
===================================

.. toctree::
   :maxdepth: 1

   history


.. tidelift-referral-banner::

.. automodule:: jaraco.functools
    :members:
    :undoc-members:
    :show-inheritance:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
