Changelog
=========



v0.6.1
------

- Use latest ScanCode toolkit packagedcode including the ability to collect
  extra index URLs from requirements.txt 
- Use new pipdeptree-like format for improved compatibility
- Rename command line tool name from "dad" to "python-inspector"


v0.5.0
------

Initial release.
