A ScanCode Toolkit plugin to provide a bundled binary for libmagic.
Libmagic itself is built from sources.
