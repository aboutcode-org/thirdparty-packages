# Changelog for https://github.com/mbarkhau/lexid

## 2021.1006

 - Minor packaging updates


## 2020.1005

 - Initial release (extracted from pycalver)
