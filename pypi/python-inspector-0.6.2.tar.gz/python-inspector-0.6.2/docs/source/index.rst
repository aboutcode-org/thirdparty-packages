Welcome to  python-inspector's documentation!
================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   dependencies-design
   test-protocol

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
