__version__ = "1.0.1"
__license__ = "MIT"
__title__ = "bumpversion"
