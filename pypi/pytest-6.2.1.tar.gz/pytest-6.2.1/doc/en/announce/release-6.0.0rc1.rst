pytest-6.0.0rc1
=======================================

pytest 6.0.0rc1 has just been released to PyPI.

This is a bug-fix release, being a drop-in replacement. To upgrade::

  pip install --upgrade pytest

The full changelog is available at https://docs.pytest.org/en/latest/changelog.html.

Thanks to all who contributed to this release, among them:

* Alfredo Deza
* Andreas Maier
* Andrew
* Anthony Sottile
* ArtyomKaltovich
* Bruno Oliveira
* Claire Cecil
* Curt J. Sampson
* Daniel
* Daniel Hahler
* Danny Sepler
* David Diaz Barquero
* Fabio Zadrozny
* Felix Nieuwenhuizen
* Florian Bruhin
* Florian Dahlitz
* Gleb Nikonorov
* Hugo van Kemenade
* Hunter Richards
* Katarzyna Król
* Katrin Leinweber
* Keri Volans
* Lewis Belcher
* Lukas Geiger
* Martin Michlmayr
* Mattwmaster58
* Maximilian Cosmo Sitter
* Nikolay Kondratyev
* Pavel Karateev
* Paweł Wilczyński
* Prashant Anand
* Ram Rachum
* Ran Benita
* Ronny Pfannschmidt
* Ruaridh Williamson
* Simon K
* Tim Hoffmann
* Tor Colvin
* Vlad-Radz
* Xinbin Huang
* Zac Hatfield-Dodds
* earonesty
* gaurav dhameeja
* gdhameeja
* ibriquem
* mcsitter
* piotrhm
* smarie
* symonk
* xuiqzy


Happy testing,
The pytest Development Team
