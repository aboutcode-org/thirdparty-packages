# flake8: noqa
"""
bad
bad bad
"""
is very bad
