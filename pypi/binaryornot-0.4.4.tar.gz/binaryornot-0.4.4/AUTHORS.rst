=======
Credits
=======

Development Lead
----------------

* Audrey Roy Greenfeld (`@audreyr`_)

Contributors
------------

* Nick Coghlan (`@ncoghlan`_)
* Ville Skyttä (`@scop`_)
* Vincent Bernat (`@vincentbernat`_)
* Daniel Roy Greenfeld (`@pydanny`_)
* Philippe Ombredanne (`@pombredanne`_)
* Aaron Meurer (`@asmeurer`_)
* David R. MacIver (`@DRMacIver`_)
* Raphael Pierzina (`@hackebrot`_)
* Johannes (`@johtso`_)
* Luke Hinds (`@lukehinds`_)

.. _`@audreyr`: https://github.com/audreyr
.. _`@ncoghlan`: https://github.com/ncoghlan
.. _`@scop`: https://github.com/scop
.. _`@vincentbernat`: https://github.com/vincentbernat
.. _`@pydanny`: https://github.com/pydanny
.. _`@pombredanne`: https://github.com/pombredanne
.. _`@asmeurer`: https://github.com/asmeurer
.. _`@DRMacIver`: https://github.com/DRMacIver
.. _`@hackebrot`: https://github.com/hackebrot
.. _`@johtso`: https://github.com/johtso
.. _`@lukehinds`: https://github.com/lukehinds
