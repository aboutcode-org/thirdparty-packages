============
Installation
============

At the command line::

    $ easy_install binaryornot

Or, if you have `pip`::

    $ pip install binaryornot
