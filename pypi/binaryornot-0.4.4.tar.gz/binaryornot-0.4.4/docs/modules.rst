binaryornot
===========

.. toctree::
   :maxdepth: 4

   binaryornot
