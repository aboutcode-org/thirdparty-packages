－－－
if table.get_length(baseObj.item_tbl) < 1 then return end
