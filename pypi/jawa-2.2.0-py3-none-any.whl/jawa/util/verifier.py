

class VerificationTypes(object):
    ITEM_Top = 0
    ITEM_Integer = 1
    ITEM_Float = 2
    ITEM_Long = 4
    ITEM_Double = 3
    ITEM_Null = 5
    ITEM_UninitializedThis = 6
    ITEM_Object = 7
    ITEM_Uninitialized = 8
