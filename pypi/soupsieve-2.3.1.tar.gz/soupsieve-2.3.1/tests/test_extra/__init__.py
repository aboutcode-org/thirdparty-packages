"""Test extra selectors not found in the CSS specifications."""
