.. _supported-versions:

Supported versions
==================

``django-guardian`` supports Python 3.5+ and Django 2.2+.

Rules
-----

* We support Python 3.5+.
* We support Django 2.2+. This is due to many simplifications in code we could
  do.
