.. _index:

=====================================================
 django-guardian - per object permissions for Django
=====================================================

:Date: |today|
:Version: |version|

**Documentation**:

.. image:: https://github.com/django-guardian/django-guardian/workflows/Tests/badge.svg?branch=devel
  :target: https://github.com/django-guardian/django-guardian/actions/workflows/tests.yml

.. toctree::
    :maxdepth: 2

    overview
    installation
    configuration
    userguide/index
    api/index
    develop/index
    license


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
