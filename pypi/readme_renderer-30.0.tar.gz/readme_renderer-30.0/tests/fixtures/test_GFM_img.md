![Image of Yaktocat](https://octodex.github.com/images/yaktocat.png)

<p align="center">
    <img src="https://octodex.github.com/images/yaktocat.png" width="20%" height="100px" alt="Image of Yaktocat">
</p>
