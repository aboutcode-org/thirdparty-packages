from debug_toolbar.panels.history.panel import HistoryPanel

__all__ = ["HistoryPanel"]
