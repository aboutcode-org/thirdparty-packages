from debug_toolbar.panels.sql.panel import SQLPanel

__all__ = ["SQLPanel"]
