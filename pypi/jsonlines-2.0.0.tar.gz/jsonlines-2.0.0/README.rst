.. image:: https://travis-ci.org/wbolster/jsonlines.svg?branch=master
   :target: https://travis-ci.org/wbolster/jsonlines

.. image:: https://pepy.tech/badge/jsonlines
   :target: https://pepy.tech/project/jsonlines

.. image:: https://pepy.tech/badge/jsonlines/month
   :target: https://pepy.tech/project/jsonlines

=========
jsonlines
=========

``jsonlines`` is a Python library to simplify working with jsonlines_
and ndjson_ data.

.. _jsonlines: http://jsonlines.org/
.. _ndjson: http://ndjson.org/

* Documentation: https://jsonlines.readthedocs.io/

* Python Package Index (PyPI): https://pypi.python.org/pypi/jsonlines/

* Source code and issue tracker: https://github.com/wbolster/jsonlines

