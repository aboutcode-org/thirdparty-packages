'symbol
'a'
'\u1234'
'\n'
