:orphan:

This file is overridden by _templates/styles.html and just exists to allow the
Styles gallery to be reliably linked from the documentation
(since its location varies between `make html` and `make dirhtml`).
