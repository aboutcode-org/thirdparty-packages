__version__ = "20220524"  # auto replaced with tag in github actions

if __name__ == "__main__":
    print(__version__)
