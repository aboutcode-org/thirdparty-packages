See http://python-prompt-toolkit.readthedocs.io/en/stable/pages/tutorials/repl.html
