debian_inspector: dpkg tests
============================


These tests are based on a heavily modified code from a subset of Debian's
python-debian and dpkg test suites are used to validate the version parsing and
comparison in the test suite. 
See https://salsa.debian.org/python-debian-team/python-debian and
https://salsa.debian.org/dpkg-team/dpkg

