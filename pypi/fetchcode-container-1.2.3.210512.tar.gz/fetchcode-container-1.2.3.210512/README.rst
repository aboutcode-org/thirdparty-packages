A ScanCode Toolkit plugin to provide pre-built binary libraries and utilities
and their locations. This is for the skopeo command which is built from source.


This is built on Debian/Ubuntu with these dependencies::

    $ sudo apt-get install -y \
        build-essential \
        libgpgme-dev \
        libassuan-dev \
        libbtrfs-dev \
        libdevmapper-dev

Then visit https://golang.org/dl/ to install Go proper. 

This version has been built with go version go1.16.3 linux/amd64
