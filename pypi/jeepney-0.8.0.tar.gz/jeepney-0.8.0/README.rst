Jeepney is a pure Python implementation of D-Bus messaging. It has an `I/O-free
<https://sans-io.readthedocs.io/>`__ core, and integration modules for different
event loops.

D-Bus is an inter-process communication system, mainly used in Linux.

To install Jeepney::

    pip install jeepney

`Jeepney docs on Readthedocs <https://jeepney.readthedocs.io/en/latest/>`__
