# dysfunctional_del.py

del  a

del  a[1]

del  a.b.c
del  ( a, b , c )
del  [ a, b , c ]

del a , b, c


del a[1]  , b [ 2]