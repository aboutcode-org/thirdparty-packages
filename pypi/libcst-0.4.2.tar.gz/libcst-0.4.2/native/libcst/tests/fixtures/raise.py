raise
raise  foo 
raise  foo  from  bar
raise  lol()  from f() + 1