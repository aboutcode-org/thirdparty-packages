#foo.

try  :
    bar()

finally  :
    pass


try   :
    pass

    # foo

except  lol  as  LOL  :

    pass

except :

    # foo

    pass

else  :

    pass

finally  :

    foo

try:
    pass
except:
    pass
finally:
    pass


try:

    # 1

    try:

        #  2

        pass

        # 3

    # 4

    finally:

        # 5

        pass
    
        # 6
    
    # 7

except foo:

    #8

    pass

    #9
