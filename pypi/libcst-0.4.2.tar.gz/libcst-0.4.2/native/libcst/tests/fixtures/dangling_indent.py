if 1:
    pass
    