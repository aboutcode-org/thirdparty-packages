if 1:
    if 2:
        if 3:
            pass