class Foo: ...

class Bar  :
    ...

class Old (  )  :
    gold : int


class OO ( Foo ) : ...

class OOP ( Foo , Bar, ) : pass

class OOPS (
    Foo ,

) :
    pass

class OOPSI ( Foo, * Bar , metaclass =
    foo ,
): pass

class OOPSIE ( list , *args, kw = arg , ** kwargs ) :
    what : does_this_even = mean

    def __init__(self) -> None:
        self.foo: Bar = Bar()
