_ = ""
_ = ''
_ = """"""
_ = ''''''

_ = 'a'   "string" 'that'   r"is" 'concatenated ' 

b"string "
b"and non f" rb'string'

(
    "parenthesized"
    "concatenated"
    """triple
    quoted
    """
    
)

_ = f"string"

f"string" "bonanza" f'starts' r"""here"""

_ = f"something {{**not** an expression}} {but(this._is)} {{and this isn't.}} end"

_(f"ok { expr = !r: aosidjhoi } end")

print(f"{self.ERASE_CURRENT_LINE}{self._human_seconds(elapsed_time)} {percent:.{self.pretty_precision}f}% complete, {self.estimate_completion(elapsed_time, finished, left)} estimated for {left} files to go...")
