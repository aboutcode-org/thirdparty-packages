#foo.

try   :
    pass

    # foo

except *  lol  as  LOL  :

    pass

except  * f:

    # foo

    pass

else  :

    pass

finally  :

    foo

try:
    pass
except*f:
    pass
finally:
    pass


try:

    # 1

    try:

        #  2

        pass

        # 3

    # 4

    finally:

        # 5

        pass
    
        # 6
    
    # 7

except *foo:

    #8

    pass

    #9
