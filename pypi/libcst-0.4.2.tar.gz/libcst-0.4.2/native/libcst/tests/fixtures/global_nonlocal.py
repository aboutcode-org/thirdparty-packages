global a
global b , c, d
nonlocal  a
nonlocal  a ,  b