# -*- coding: utf-8 -*-
def test_function():
    import funcmultiplier
