from .registry import *

__title__ = 'regipy'
__version__ = '2.0.0'
