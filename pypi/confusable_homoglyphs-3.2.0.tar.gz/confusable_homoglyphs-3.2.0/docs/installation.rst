============
Installation
============

At the command line::

    $ easy_install confusable_homoglyphs

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv confusable_homoglyphs
    $ pip install confusable_homoglyphs
