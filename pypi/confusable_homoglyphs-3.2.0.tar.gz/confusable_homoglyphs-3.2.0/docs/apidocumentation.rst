=================
API Documentation
=================

.. include:: ./confusable_homoglyphs.rst
