confusable\_homoglyphs package
==============================

Submodules
----------

confusable\_homoglyphs\.categories module
-----------------------------------------

.. automodule:: confusable_homoglyphs.categories
    :members:
    :undoc-members:
    :show-inheritance:

confusable\_homoglyphs\.cli module
----------------------------------

.. automodule:: confusable_homoglyphs.cli
    :members:
    :undoc-members:
    :show-inheritance:

confusable\_homoglyphs\.confusables module
------------------------------------------

.. automodule:: confusable_homoglyphs.confusables
    :members:
    :undoc-members:
    :show-inheritance:

confusable\_homoglyphs\.utils module
------------------------------------

.. automodule:: confusable_homoglyphs.utils
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: confusable_homoglyphs
    :members:
    :undoc-members:
    :show-inheritance:
