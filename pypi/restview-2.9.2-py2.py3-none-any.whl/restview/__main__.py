"""
This module contains the entry point to restview.
"""
from restview.restviewhttp import main

if __name__ == '__main__':
    main()
