=============
API Reference
=============

``importlib_metadata`` module
-----------------------------

.. automodule:: importlib_metadata
   :members:
   :undoc-members:
   :show-inheritance:
