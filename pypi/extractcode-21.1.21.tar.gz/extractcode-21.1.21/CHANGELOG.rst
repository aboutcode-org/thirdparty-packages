Release notes
=============

vNext
-----

Version 21.1.21
---------------

*2021-01-21*
- Add new [full] extra requires that install all the dependencies
- Fix bug related to commoncode libraries loading
- Improve the extra requirements
- Set minimum version for dependencies
- Improve documentation


Version 21.1.15
---------------

*2021-01-15*
- Drop support for Python 2
- Use the latest CommonCode and TypeCode libraries

*2020-11-13*
- Add azure-pipelines CI support


Version 20.10
-------------

*2020-10-06*
- Initial release.
