try:
    from test.support.os_helpers import FS_NONASCII
except ImportError:
    from test.support import FS_NONASCII  # noqa
