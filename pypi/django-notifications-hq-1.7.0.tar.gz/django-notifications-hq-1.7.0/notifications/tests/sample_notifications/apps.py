from notifications.apps import Config as NotificationConfig


class SampleNotificationsConfig(NotificationConfig):
    name = 'notifications.tests.sample_notifications'
    label = 'sample_notifications'
