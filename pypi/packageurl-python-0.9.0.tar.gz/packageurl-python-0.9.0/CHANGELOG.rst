Changelog
=========

0.9.0 (2020-05-21)
------------------

- Make PackageURL hashable.
- Add cargo type or url2purl
- Increase the size of the Django model contrib version to 100 chars.
- Remove Python 3 idioms (f strings)

0.8.7 (2019-08-15)
------------------

- Add max length validation to the Django model contrib.
