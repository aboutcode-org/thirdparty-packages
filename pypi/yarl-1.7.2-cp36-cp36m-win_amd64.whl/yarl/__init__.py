from ._url import URL, cache_clear, cache_configure, cache_info

__version__ = "1.7.2"

__all__ = ("URL", "cache_clear", "cache_configure", "cache_info")
