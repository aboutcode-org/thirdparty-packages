To keep the git history, we used these:

1. Use git-filter-repo from https://github.com/newren/git-filter-repo/
   And this script git-filter-repo-pip.sh

2. Then use git-rename-merge.sh to combine files in sequence

There have been other manual intermediate commits to remove unused code

Finally the code was adjusted and cleaned by hand.
