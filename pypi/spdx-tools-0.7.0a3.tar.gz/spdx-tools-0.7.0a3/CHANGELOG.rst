Changelog
=========


v0.7.0 (2021-09-16)
---------------------

Starting a Changelog.

- Drop Python 2 support
- Add new LicenseListVersion tag
- Move version to SPDX version 2.2 

Thank you to these contributors:

- Pierre Tardy @tardyp
- Kyle Altendorf @altendky
- Santiago Torres @SantiagoTorres
- Shubham Kumar Jha @ShubhamKJha
- Yash Varshney @Yash-Varshney
- Gary O'Neall @goneall
- Cole Helbling @cole-h
- Jeff Licquia @licquia
- Alberto Pianon @alpianon
- Nathan Voss @njv299
- Philippe Ombredanne @pombredanne
