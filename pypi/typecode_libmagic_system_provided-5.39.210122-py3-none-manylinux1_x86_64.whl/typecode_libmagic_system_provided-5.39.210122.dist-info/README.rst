A ScanCode Toolkit plugin to use pre-installed system binary libraries and utilities.
