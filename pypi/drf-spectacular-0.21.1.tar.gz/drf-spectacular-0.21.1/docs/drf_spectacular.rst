Package overview
================

drf\_spectacular\.utils
-----------------------
.. automodule:: drf_spectacular.utils
    :members:
    :undoc-members:
    :show-inheritance:

drf\_spectacular\.types
-----------------------
.. autoclass:: drf_spectacular.types.OpenApiTypes
    :members:
    :undoc-members:
    :member-order: bysource

drf\_spectacular\.views
-----------------------
.. automodule:: drf_spectacular.views
    :members:
    :undoc-members:
    :show-inheritance:

drf\_spectacular\.extensions
----------------------------
.. automodule:: drf_spectacular.extensions
    :members:
    :undoc-members:
    :show-inheritance:

drf\_spectacular\.hooks
-----------------------
.. automodule:: drf_spectacular.hooks
    :members:
    :undoc-members:
    :show-inheritance:

drf\_spectacular\.openapi
-------------------------
.. automodule:: drf_spectacular.openapi
    :members:
    :undoc-members:
    :show-inheritance:

drf\_spectacular\.contrib\.django_filters
-----------------------------------------
.. automodule:: drf_spectacular.contrib.django_filters
    :members:
    :show-inheritance:
