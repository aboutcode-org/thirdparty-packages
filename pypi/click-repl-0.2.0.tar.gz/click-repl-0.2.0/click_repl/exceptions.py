class InternalCommandException(Exception):
    pass


class ExitReplException(InternalCommandException):
    pass
