=======
History
=======

0.1.0 (2016-06-02)
------------------

* First release on PyPI.
