#!/usr/bin/env python3
import setuptools

setuptools.setup()  # For compatibility with python 3.6
