Installing Python-Markdown
==========================

As an Admin/Root user on your system do:

    pip install markdown

Or for more specific instructions, view the documentation in `docs/install.md`
or on the website at <https://Python-Markdown.github.io/install/>.
