debian\_inspector.package module
================================

.. automodule:: debian_inspector.package
   :members:
   :undoc-members:
   :show-inheritance:
