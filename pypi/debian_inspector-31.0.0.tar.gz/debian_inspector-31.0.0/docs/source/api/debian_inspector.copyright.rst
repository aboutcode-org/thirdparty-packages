debian\_inspector.copyright module
==================================

.. automodule:: debian_inspector.copyright
   :members:
   :undoc-members:
   :show-inheritance:
