debian\_inspector.coverage module
=================================

.. automodule:: debian_inspector.coverage
   :members:
   :undoc-members:
   :show-inheritance:
