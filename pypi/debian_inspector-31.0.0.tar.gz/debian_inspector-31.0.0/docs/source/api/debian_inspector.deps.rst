debian\_inspector.deps module
=============================

.. automodule:: debian_inspector.deps
   :members:
   :undoc-members:
   :show-inheritance:
