debian\_inspector package
=========================

.. automodule:: debian_inspector
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   debian_inspector.contents
   debian_inspector.copyright
   debian_inspector.coverage
   debian_inspector.deb822
   debian_inspector.debcon
   debian_inspector.deps
   debian_inspector.package
   debian_inspector.unsign
   debian_inspector.utils
   debian_inspector.version
