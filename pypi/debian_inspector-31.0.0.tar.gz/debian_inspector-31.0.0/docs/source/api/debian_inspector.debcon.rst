debian\_inspector.debcon module
===============================

.. automodule:: debian_inspector.debcon
   :members:
   :undoc-members:
   :show-inheritance:
