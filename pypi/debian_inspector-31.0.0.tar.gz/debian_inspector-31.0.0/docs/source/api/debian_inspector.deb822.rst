debian\_inspector.deb822 module
===============================

.. automodule:: debian_inspector.deb822
   :members:
   :undoc-members:
   :show-inheritance:
