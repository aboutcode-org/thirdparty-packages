debian\_inspector.version module
================================

.. automodule:: debian_inspector.version
   :members:
   :undoc-members:
   :show-inheritance:
