---
name: Propose a new itertool
about: Suggest a new itertool for the library
title: ''
labels: ''
assignees: ''

---

### Description
<!-- Explain what your proposed itertools does here -->

### References
<!-- Link to a discussion on, e.g. Stack Overflow, showing where the new tool would have been useful -->
<!-- Or link to a GitHub issue in another repository -->
<!-- Or a discussion on the python-ideas mailing list -->
<!-- Alternatively, describe a real problem you had to solve with this itertool -->

### Examples
<!-- Provide a code sample showing how your itertool works -->
