:orphan:

================================
Messaging for Parallel Computing
================================

IPython parallel has moved to ipyparallel -
see :ref:`ipyparallel:/reference/messages.md` for the documentation.
