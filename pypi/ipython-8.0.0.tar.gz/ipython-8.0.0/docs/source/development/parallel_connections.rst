:orphan:

==============================================
Connection Diagrams of The IPython ZMQ Cluster
==============================================

IPython parallel has moved to ipyparallel -
see :ref:`ipyparallel:/reference/connections.md` for the documentation.
