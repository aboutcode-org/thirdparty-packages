.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.ipstruct`
=============================
.. automodule:: IPython.utils.ipstruct

.. currentmodule:: IPython.utils.ipstruct

1 Class
-------

.. autoclass:: Struct
  :members:
  :show-inheritance:

  .. automethod:: __init__
