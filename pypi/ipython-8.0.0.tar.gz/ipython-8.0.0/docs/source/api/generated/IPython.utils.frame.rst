.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.frame`
==========================
.. automodule:: IPython.utils.frame

.. currentmodule:: IPython.utils.frame

4 Functions
-----------

.. autofunction:: IPython.utils.frame.extract_vars


.. autofunction:: IPython.utils.frame.extract_vars_above


.. autofunction:: IPython.utils.frame.debugx


.. autofunction:: IPython.utils.frame.extract_module_locals

