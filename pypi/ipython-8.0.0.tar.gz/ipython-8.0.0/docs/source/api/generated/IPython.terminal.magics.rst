.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`terminal.magics`
==============================
.. automodule:: IPython.terminal.magics

.. currentmodule:: IPython.terminal.magics

1 Class
-------

.. autoclass:: TerminalMagics
  :members:
  :show-inheritance:

  .. automethod:: __init__

1 Function
----------

.. autofunction:: IPython.terminal.magics.get_pasted_lines

