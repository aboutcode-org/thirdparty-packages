.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.inputsplitter`
=================================
.. automodule:: IPython.core.inputsplitter

.. currentmodule:: IPython.core.inputsplitter

4 Classes
---------

.. autoclass:: IncompleteString
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: InMultilineStatement
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: InputSplitter
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: IPythonInputSplitter
  :members:
  :show-inheritance:

  .. automethod:: __init__

7 Functions
-----------

.. autofunction:: IPython.core.inputsplitter.num_ini_spaces


.. autofunction:: IPython.core.inputsplitter.partial_tokens


.. autofunction:: IPython.core.inputsplitter.find_next_indent


.. autofunction:: IPython.core.inputsplitter.last_blank


.. autofunction:: IPython.core.inputsplitter.last_two_blanks


.. autofunction:: IPython.core.inputsplitter.remove_comments


.. autofunction:: IPython.core.inputsplitter.get_input_encoding

