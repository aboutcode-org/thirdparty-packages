.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.extensions`
==============================
.. automodule:: IPython.core.extensions

.. currentmodule:: IPython.core.extensions

1 Class
-------

.. autoclass:: ExtensionManager
  :members:
  :show-inheritance:

  .. automethod:: __init__
