.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.io`
=======================
.. automodule:: IPython.utils.io

.. currentmodule:: IPython.utils.io

1 Class
-------

.. autoclass:: Tee
  :members:
  :show-inheritance:

  .. automethod:: __init__

2 Functions
-----------

.. autofunction:: IPython.utils.io.ask_yes_no


.. autofunction:: IPython.utils.io.temp_pyfile

