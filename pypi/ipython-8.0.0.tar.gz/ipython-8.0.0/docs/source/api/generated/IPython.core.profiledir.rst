.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.profiledir`
==============================
.. automodule:: IPython.core.profiledir

.. currentmodule:: IPython.core.profiledir

2 Classes
---------

.. autoclass:: ProfileDirError
  :members:
  :show-inheritance:

.. autoclass:: ProfileDir
  :members:
  :show-inheritance:
