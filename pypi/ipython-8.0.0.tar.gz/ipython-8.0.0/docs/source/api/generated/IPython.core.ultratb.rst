.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.ultratb`
===========================
.. automodule:: IPython.core.ultratb

.. currentmodule:: IPython.core.ultratb

7 Classes
---------

.. autoclass:: TBTools
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: ListTB
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: VerboseTB
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: FormattedTB
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: AutoFormattedTB
  :members:
  :show-inheritance:

.. autoclass:: ColorTB
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: SyntaxTB
  :members:
  :show-inheritance:

  .. automethod:: __init__

3 Functions
-----------

.. autofunction:: IPython.core.ultratb.text_repr


.. autofunction:: IPython.core.ultratb.eqrepr


.. autofunction:: IPython.core.ultratb.nullrepr

