.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.compilerop`
==============================
.. automodule:: IPython.core.compilerop

.. currentmodule:: IPython.core.compilerop

1 Class
-------

.. autoclass:: CachingCompiler
  :members:
  :show-inheritance:

  .. automethod:: __init__

2 Functions
-----------

.. autofunction:: IPython.core.compilerop.code_name


.. autofunction:: IPython.core.compilerop.check_linecache_ipython

