.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`lib.deepreload`
=============================
.. automodule:: IPython.lib.deepreload

.. currentmodule:: IPython.lib.deepreload

9 Functions
-----------

.. autofunction:: IPython.lib.deepreload.replace_import_hook


.. autofunction:: IPython.lib.deepreload.get_parent


.. autofunction:: IPython.lib.deepreload.load_next


.. autofunction:: IPython.lib.deepreload.import_submodule


.. autofunction:: IPython.lib.deepreload.add_submodule


.. autofunction:: IPython.lib.deepreload.ensure_fromlist


.. autofunction:: IPython.lib.deepreload.deep_import_hook


.. autofunction:: IPython.lib.deepreload.deep_reload_hook


.. autofunction:: IPython.lib.deepreload.reload

