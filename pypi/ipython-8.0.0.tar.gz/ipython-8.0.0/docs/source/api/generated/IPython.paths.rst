.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`paths`
====================
.. automodule:: IPython.paths

.. currentmodule:: IPython.paths

5 Functions
-----------

.. autofunction:: IPython.paths.get_ipython_dir


.. autofunction:: IPython.paths.get_ipython_cache_dir


.. autofunction:: IPython.paths.get_ipython_package_dir


.. autofunction:: IPython.paths.get_ipython_module_path


.. autofunction:: IPython.paths.locate_profile

