.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.builtin_trap`
================================
.. automodule:: IPython.core.builtin_trap

.. currentmodule:: IPython.core.builtin_trap

1 Class
-------

.. autoclass:: BuiltinTrap
  :members:
  :show-inheritance:

  .. automethod:: __init__
