.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.syspathcontext`
===================================
.. automodule:: IPython.utils.syspathcontext

.. currentmodule:: IPython.utils.syspathcontext

2 Classes
---------

.. autoclass:: appended_to_syspath
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: prepended_to_syspath
  :members:
  :show-inheritance:

  .. automethod:: __init__
