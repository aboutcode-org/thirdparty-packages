.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.magic`
=========================
.. automodule:: IPython.core.magic

.. currentmodule:: IPython.core.magic

4 Classes
---------

.. autoclass:: Bunch
  :members:
  :show-inheritance:

.. autoclass:: MagicsManager
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: Magics
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: MagicAlias
  :members:
  :show-inheritance:

  .. automethod:: __init__

7 Functions
-----------

.. autofunction:: IPython.core.magic.on_off


.. autofunction:: IPython.core.magic.compress_dhist


.. autofunction:: IPython.core.magic.needs_local_scope


.. autofunction:: IPython.core.magic.magics_class


.. autofunction:: IPython.core.magic.record_magic


.. autofunction:: IPython.core.magic.validate_type


.. autofunction:: IPython.core.magic.no_var_expand

