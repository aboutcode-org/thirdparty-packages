.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.excolors`
============================
.. automodule:: IPython.core.excolors

.. currentmodule:: IPython.core.excolors

1 Function
----------

.. autofunction:: IPython.core.excolors.exception_colors

