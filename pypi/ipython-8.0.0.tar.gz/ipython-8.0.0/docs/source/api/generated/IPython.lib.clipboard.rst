.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`lib.clipboard`
============================
.. automodule:: IPython.lib.clipboard

.. currentmodule:: IPython.lib.clipboard

1 Class
-------

.. autoclass:: ClipboardEmpty
  :members:
  :show-inheritance:

3 Functions
-----------

.. autofunction:: IPython.lib.clipboard.win32_clipboard_get


.. autofunction:: IPython.lib.clipboard.osx_clipboard_get


.. autofunction:: IPython.lib.clipboard.tkinter_clipboard_get

