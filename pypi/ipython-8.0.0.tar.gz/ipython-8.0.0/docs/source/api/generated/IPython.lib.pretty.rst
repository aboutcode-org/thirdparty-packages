.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`lib.pretty`
=========================
.. automodule:: IPython.lib.pretty

.. currentmodule:: IPython.lib.pretty

10 Classes
----------

.. autoclass:: PrettyPrinter
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: RepresentationPrinter
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: Printable
  :members:
  :show-inheritance:

.. autoclass:: Text
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: Breakable
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: Group
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: GroupQueue
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: RawText
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: CallExpression
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: RawStringLiteral
  :members:
  :show-inheritance:

  .. automethod:: __init__

4 Functions
-----------

.. autofunction:: IPython.lib.pretty.pretty


.. autofunction:: IPython.lib.pretty.pprint


.. autofunction:: IPython.lib.pretty.for_type


.. autofunction:: IPython.lib.pretty.for_type_by_name

