.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.async_helpers`
=================================
.. automodule:: IPython.core.async_helpers

.. currentmodule:: IPython.core.async_helpers

1 Function
----------

.. autofunction:: IPython.core.async_helpers.get_asyncio_loop

