.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.pylabtools`
==============================
.. automodule:: IPython.core.pylabtools

.. currentmodule:: IPython.core.pylabtools

10 Functions
------------

.. autofunction:: IPython.core.pylabtools.getfigs


.. autofunction:: IPython.core.pylabtools.figsize


.. autofunction:: IPython.core.pylabtools.print_figure


.. autofunction:: IPython.core.pylabtools.retina_figure


.. autofunction:: IPython.core.pylabtools.mpl_runner


.. autofunction:: IPython.core.pylabtools.select_figure_formats


.. autofunction:: IPython.core.pylabtools.find_gui_and_backend


.. autofunction:: IPython.core.pylabtools.activate_matplotlib


.. autofunction:: IPython.core.pylabtools.import_pylab


.. autofunction:: IPython.core.pylabtools.configure_inline_support

