.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`terminal.debugger`
================================
.. automodule:: IPython.terminal.debugger

.. currentmodule:: IPython.terminal.debugger

1 Class
-------

.. autoclass:: TerminalPdb
  :members:
  :show-inheritance:

  .. automethod:: __init__

1 Function
----------

.. autofunction:: IPython.terminal.debugger.set_trace

