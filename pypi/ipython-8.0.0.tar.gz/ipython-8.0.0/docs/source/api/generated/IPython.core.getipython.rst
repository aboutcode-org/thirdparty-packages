.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.getipython`
==============================
.. automodule:: IPython.core.getipython

.. currentmodule:: IPython.core.getipython

1 Function
----------

.. autofunction:: IPython.core.getipython.get_ipython

