.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.profileapp`
==============================
.. automodule:: IPython.core.profileapp

.. currentmodule:: IPython.core.profileapp

4 Classes
---------

.. autoclass:: ProfileLocate
  :members:
  :show-inheritance:

.. autoclass:: ProfileList
  :members:
  :show-inheritance:

.. autoclass:: ProfileCreate
  :members:
  :show-inheritance:

.. autoclass:: ProfileApp
  :members:
  :show-inheritance:

2 Functions
-----------

.. autofunction:: IPython.core.profileapp.list_profiles_in


.. autofunction:: IPython.core.profileapp.list_bundled_profiles

