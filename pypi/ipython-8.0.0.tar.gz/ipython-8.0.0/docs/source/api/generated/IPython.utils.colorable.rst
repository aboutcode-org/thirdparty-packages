.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.colorable`
==============================
.. automodule:: IPython.utils.colorable

.. currentmodule:: IPython.utils.colorable

1 Class
-------

.. autoclass:: Colorable
  :members:
  :show-inheritance:
