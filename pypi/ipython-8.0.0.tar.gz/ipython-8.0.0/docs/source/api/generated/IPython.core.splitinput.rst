.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.splitinput`
==============================
.. automodule:: IPython.core.splitinput

.. currentmodule:: IPython.core.splitinput

1 Class
-------

.. autoclass:: LineInfo
  :members:
  :show-inheritance:

  .. automethod:: __init__

1 Function
----------

.. autofunction:: IPython.core.splitinput.split_user_input

