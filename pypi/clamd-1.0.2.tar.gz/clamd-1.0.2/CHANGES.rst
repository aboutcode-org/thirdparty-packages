Changes
=========

1.0.2 (2014-08-21)
------------------

- Remove all dependencies. clamd is now standalone!
- Use plain setuptools no d2to1.
- Create universal wheel.


1.0.1 (2013-03-06)
------------------

- Updated d2to1 dependency


1.0.0 (2013-02-08)
------------------

- Change public interface, including exceptions
- Support Python 3.3, withdraw 2.5 support


0.3.4 (2013-02-01)
------------------

- Use regex to parse file status reponse instead of complicated string split/join


0.3.3 (2013-01-28)
------------------

- First version of clamd that can be installed from PyPI
