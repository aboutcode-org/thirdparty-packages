Release notes
=============

vNext
-----

Version 21.1.15
-------------

*2021-01-15*
- Drop support for Python 2
- Use the latest CommonCode and TypeCode libraries

*2020-11-13*
- Add azure-pipelines CI support


Version 20.10
-------------

*2020-10-06*
- Initial release.
