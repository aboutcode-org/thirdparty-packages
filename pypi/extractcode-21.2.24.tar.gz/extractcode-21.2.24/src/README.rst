Put your Python source code (and installable data) in this directory.

