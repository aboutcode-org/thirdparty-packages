Developer reference
===================

.. note::

  The documentation here is quite outdated and has been neglected. Many objects worthy
  of inclusion aren't documented. Contributions are appreciated!

*Contents are subject to change.*

.. toctree::
   :maxdepth: 2

   reference_classes
   reference_functions
   reference_exceptions
