=====
Usage
=====

To use tblib in a project::

	import tblib
