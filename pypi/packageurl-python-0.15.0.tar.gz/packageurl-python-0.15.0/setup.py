#!/usr/bin/env python
# -*- encoding: utf-8 -*-

# SPDX-License-Identifier: MIT

import setuptools

if __name__ == "__main__":
    setuptools.setup()
