def hello_task(who='world'):
    print(f'Hello {who}')
