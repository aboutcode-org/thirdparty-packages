========================================
 Getting Started
========================================

.. include:: includes/introduction.txt

.. include:: includes/installation.txt

.. include:: includes/resources.txt
