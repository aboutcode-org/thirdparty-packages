================================================
 Etcd Transport - ``kombu.transport.etcd``
================================================

.. currentmodule:: kombu.transport.etcd

.. automodule:: kombu.transport.etcd

    .. contents::
        :local:

    Transport
    ---------

    .. autoclass:: Transport
        :members:
        :undoc-members:

    Channel
    -------

    .. autoclass:: Channel
        :members:
        :undoc-members:
