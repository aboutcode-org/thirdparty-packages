#!/bin/sh

export PYTHONPATH=`pwd`
python tests/decoding_test.py
