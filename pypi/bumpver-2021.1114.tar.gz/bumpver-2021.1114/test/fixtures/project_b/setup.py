import setuptools

setuptools.setup(
    name="mylib",
    license="MIT",
    version="201307.456b0",
    keywords="awesome library",
)
