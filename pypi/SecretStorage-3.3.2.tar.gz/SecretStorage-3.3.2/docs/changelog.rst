=======================
SecretStorage changelog
=======================

This changelog only lists the most important changes that happened in
SecretStorage. Please see the `Git log`_ for the full list of changes.

.. _`Git log`: https://github.com/mitya57/secretstorage/commits/master

.. include:: ../changelog
